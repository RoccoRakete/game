CATCHER CAR: RAIL RUSH — OFFLINE-SICHERUNG
Version 12 mit der überarbeiteten 3D-Verhaftungsszene

SPIELEN AUF MAC:
1. ZIP-Datei vollständig entpacken.
2. SPIEL_STARTEN.html doppelt anklicken.
3. Alternativ STARTEN.command öffnen.

SPIELEN AUF WINDOWS:
1. ZIP-Datei vollständig entpacken.
2. SPIEL_STARTEN.html oder STARTEN-WINDOWS.bat öffnen.

WICHTIG:
Das Spiel ist vollständig in SPIEL_STARTEN.html eingebettet und benötigt beim Spielen keine Internetverbindung.
Spielstand, Münzen, gekaufte Fahrzeuge und Verbesserungen werden vom Browser auf diesem Computer gespeichert.
Falls der Ton nicht sofort startet, einmal in das Spiel klicken und die Mission starten.

BACKUP:
Der Ordner Quellcode enthält zusätzlich den vollständigen Entwicklungsstand zum späteren Wiederherstellen oder Bearbeiten.
