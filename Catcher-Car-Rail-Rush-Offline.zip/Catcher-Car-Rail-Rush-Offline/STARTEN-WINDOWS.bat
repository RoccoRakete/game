@echo off
start "" "%~dp0SPIEL_STARTEN.html"
