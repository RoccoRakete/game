"use client";

export type GameAudio = {
  startTrack: (level: number) => Promise<boolean>;
  setMuted: (muted: boolean) => void;
  updateEngine: (speed: number, boosting: boolean) => void;
  pause: () => void;
  resume: () => void;
  jump: () => void;
  coin: () => void;
  power: () => void;
  impact: () => void;
  caught: () => void;
  handcuffs: () => void;
  complete: () => void;
  stop: () => void;
};

type Track = {
  tempo: number;
  bass: number[];
  lead: number[];
  wave: OscillatorType;
  color: number;
  groove: number;
};

export const MUSIC_TRACKS = [
  "Desert Pursuit", "Neon Velocity", "Frozen Rails", "Volcano Run", "Skyline Escape",
  "Eye of the Sandstorm", "Cyber Tunnel Rush", "Crystal Lake Drift", "Magma Shaft", "Cloudport Chase",
  "Temple Overdrive", "Hologram Highway", "Polar Night Express", "Reactor Redline", "Thunderbridge",
  "Emerald Horizon", "Matrix Pursuit", "Ice Cathedral", "Molten Orbit", "Citadel Storm",
  "Dune Metropolis", "Quantum Loop", "Aurora Rails", "Vortex Core", "Ion Skyway",
  "Solar Hyperdrive", "Chrono City", "Diamond Express", "Galaxy Crater", "Omega Finale",
] as const;

const TEMPOS = [112, 138, 96, 126, 146, 121, 154, 102, 132, 142, 118, 150, 106, 136, 148, 124, 158, 110, 140, 152, 128, 162, 114, 144, 156, 134, 166, 120, 150, 172];
const ROOTS = [82.41, 92.5, 73.42, 65.41, 110, 87.31, 98, 77.78, 69.3, 116.54, 73.42, 103.83, 82.41, 61.74, 123.47, 92.5, 110, 69.3, 77.78, 130.81, 98, 116.54, 87.31, 65.41, 138.59, 103.83, 123.47, 73.42, 146.83, 110];
const SCALES = [[0, 3, 5, 7, 10, 12], [0, 2, 5, 7, 9, 12], [0, 3, 5, 8, 10, 12], [0, 2, 4, 7, 9, 11, 12], [0, 2, 3, 7, 8, 12]];
const PATTERNS = [[0, 2, 4, 3, 1, 2, 0, 1], [0, 3, 5, 4, 3, 1, 2, 4], [4, 3, 2, 1, 0, 2, 3, 1], [0, 1, 3, 5, 4, 2, 1, 3], [0, 4, 2, 5, 3, 1, 4, 2], [5, 3, 1, 2, 4, 0, 3, 1]];
const WAVES: OscillatorType[] = ["triangle", "sawtooth", "sine", "square"];
const note = (root: number, semitones: number, octave = 0) => root * Math.pow(2, semitones / 12 + octave);

const TRACKS: Track[] = MUSIC_TRACKS.map((_, index) => {
  const root = ROOTS[index];
  const scale = SCALES[index % SCALES.length];
  const pattern = PATTERNS[index % PATTERNS.length];
  const lead = pattern.map((degree, step) => note(root, scale[(degree + Math.floor(index / 6)) % scale.length], 2 + ((step + index) % 7 === 0 ? 1 : 0)));
  const bass = [0, 3, 4, 2].map((degree, step) => note(root, scale[(degree + index + step) % scale.length], step === 3 && index % 2 ? -1 : 0));
  return { tempo: TEMPOS[index], bass, lead, wave: WAVES[(index + Math.floor(index / 5)) % WAVES.length], color: 0.42 + (index % 7) * 0.075, groove: 2 + (index % 4) };
});

const MUSIC_VOLUME = 0.82;
const SFX_VOLUME = 0.55;
const ENGINE_MAX_VOLUME = 0.032;

export function createGameAudio(): GameAudio {
  let context: AudioContext | null = null;
  let master: GainNode | null = null;
  let musicBus: GainNode | null = null;
  let sfxBus: GainNode | null = null;
  let engineOscillator: OscillatorNode | null = null;
  let engineGain: GainNode | null = null;
  let timer: ReturnType<typeof setInterval> | null = null;
  let currentLevel = -1;
  let step = 0;
  let muted = false;

  const ensure = () => {
    if (context && master && musicBus && sfxBus) return true;
    const AudioCtor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return false;
    context = new AudioCtor();
    master = context.createGain();
    musicBus = context.createGain();
    sfxBus = context.createGain();
    master.gain.value = muted ? 0 : 0.9;
    musicBus.gain.value = MUSIC_VOLUME;
    sfxBus.gain.value = SFX_VOLUME;
    musicBus.connect(master);
    sfxBus.connect(master);
    master.connect(context.destination);
    engineOscillator = context.createOscillator();
    engineOscillator.type = "sawtooth";
    engineGain = context.createGain();
    engineGain.gain.value = 0;
    engineOscillator.connect(engineGain);
    engineGain.connect(sfxBus);
    engineOscillator.start();
    return true;
  };

  const tone = (frequency: number, duration: number, wave: OscillatorType, volume: number, destination = sfxBus, offset = 0) => {
    if (!context || !destination) return;
    const start = context.currentTime + offset;
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    oscillator.type = wave;
    oscillator.frequency.setValueAtTime(frequency, start);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume), start + 0.018);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    oscillator.connect(gain);
    gain.connect(destination);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.03);
  };

  const noise = (duration: number, volume: number, offset = 0, destination = sfxBus) => {
    if (!context || !destination) return;
    const length = Math.max(1, Math.floor(context.sampleRate * duration));
    const buffer = context.createBuffer(1, length, context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / length);
    const source = context.createBufferSource();
    const filter = context.createBiquadFilter();
    const gain = context.createGain();
    filter.type = "bandpass";
    filter.frequency.value = 850;
    gain.gain.value = volume;
    source.buffer = buffer;
    source.connect(filter);
    filter.connect(gain);
    gain.connect(destination);
    source.start(context.currentTime + offset);
  };

  const musicTick = () => {
    if (!context || !musicBus || currentLevel < 0) return;
    const track = TRACKS[currentLevel];
    const style = currentLevel % 5;
    const bassNote = track.bass[Math.floor(step / 2) % track.bass.length];
    const leadNote = track.lead[step % track.lead.length];
    if (step % 2 === 0) tone(bassNote, 0.24, "square", 0.055, musicBus);
    if ((step + currentLevel) % track.groove !== track.groove - 1) tone(leadNote, style === 2 ? 0.42 : 0.16, track.wave, 0.028 + track.color * 0.015, musicBus, 0.015);
    if (step % 4 === 0) {
      tone(48, 0.12, "sine", 0.13, musicBus);
      tone(72, 0.08, "sine", 0.07, musicBus, 0.025);
    }
    if (step % 4 === 2 && style !== 2) noise(0.055, 0.024, 0, musicBus);
    if (style === 1 && step % 2 === 1) tone(leadNote * 2, 0.07, "square", 0.012, musicBus);
    if (style === 3 && step % 2 === 0) noise(0.035, 0.04, 0, musicBus);
    if (style === 4 && step % 4 === 3) tone(leadNote * 1.5, 0.16, "triangle", 0.018, musicBus);
    step++;
  };

  const startTrack = async (level: number) => {
    if (!ensure() || !context || !musicBus) return false;
    const safeLevel = Math.min(TRACKS.length - 1, Math.max(0, level));
    if (timer) clearInterval(timer);
    timer = null;
    currentLevel = safeLevel;
    step = 0;
    try {
      if (context.state !== "running") await context.resume();
    } catch {
      return false;
    }
    if (context.state !== "running") return false;
    const track = TRACKS[safeLevel];
    const interval = (60_000 / track.tempo) / 2;
    musicBus.gain.cancelScheduledValues(context.currentTime);
    musicBus.gain.setTargetAtTime(MUSIC_VOLUME, context.currentTime, 0.06);
    tone(track.lead[0], 0.16, "triangle", 0.075, musicBus);
    tone(track.lead[0] * 1.5, 0.2, "sine", 0.045, musicBus, 0.07);
    musicTick();
    timer = setInterval(musicTick, interval);
    return true;
  };

  return {
    startTrack,
    setMuted(value) {
      muted = value;
      if (!master || !context) return;
      master.gain.setTargetAtTime(value ? 0 : 0.9, context.currentTime, 0.04);
    },
    updateEngine(speed, boosting) {
      if (!context || !engineOscillator || !engineGain) return;
      engineOscillator.frequency.setTargetAtTime(48 + speed * 1.15 + (boosting ? 55 : 0), context.currentTime, 0.045);
      engineGain.gain.setTargetAtTime(Math.min(ENGINE_MAX_VOLUME, 0.005 + speed / 8000), context.currentTime, 0.05);
    },
    pause() {
      if (!context || !musicBus || !engineGain) return;
      musicBus.gain.setTargetAtTime(0.035, context.currentTime, 0.08);
      engineGain.gain.setTargetAtTime(0.004, context.currentTime, 0.08);
    },
    resume() {
      if (!context || !musicBus) return;
      void context.resume();
      musicBus.gain.setTargetAtTime(MUSIC_VOLUME, context.currentTime, 0.08);
    },
    jump() { if (ensure()) { tone(170, 0.24, "sine", 0.11); tone(360, 0.2, "triangle", 0.07, sfxBus, 0.08); } },
    coin() { if (ensure()) { tone(880, 0.11, "sine", 0.12); tone(1320, 0.16, "triangle", 0.08, sfxBus, 0.055); } },
    power() { if (ensure()) { [261.63, 392, 523.25].forEach((note, index) => tone(note, 0.38, "sawtooth", 0.055, sfxBus, index * 0.045)); } },
    impact() { if (ensure()) { noise(0.28, 0.22); tone(62, 0.34, "sawtooth", 0.12); } },
    caught() {
      if (!ensure()) return;
      for (let i = 0; i < 8; i++) tone(i % 2 ? 660 : 440, 0.2, "sine", 0.085, sfxBus, i * 0.18);
      noise(0.4, 0.08);
    },
    handcuffs() {
      if (!ensure()) return;
      noise(0.045, 0.16);
      tone(1800, 0.08, "square", 0.08, sfxBus, 0.03);
      noise(0.045, 0.13, 0.22);
      tone(1450, 0.09, "square", 0.07, sfxBus, 0.25);
    },
    complete() { if (ensure()) [392, 523.25, 659.25, 783.99].forEach((note, index) => tone(note, 0.42, "triangle", 0.08, sfxBus, index * 0.11)); },
    stop() {
      if (timer) clearInterval(timer);
      timer = null;
      currentLevel = -1;
      if (context) void context.close();
      context = null;
      master = null;
      musicBus = null;
      sfxBus = null;
      engineOscillator = null;
      engineGain = null;
    },
  };
}
