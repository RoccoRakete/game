"use client";

import { useEffect, useState } from "react";
import type { ComponentType } from "react";

export default function Home() {
  const [Game, setGame] = useState<ComponentType | null>(null);

  useEffect(() => {
    let active = true;
    import("./catcher-car-game").then((module) => {
      if (active) setGame(() => module.default);
    });
    return () => { active = false; };
  }, []);

  if (!Game) {
    return (
      <main className="game-loader" aria-label="Catcher Car Rail Rush wird geladen">
        <div className="loader-brand"><span>CC</span><strong>RAIL RUSH</strong></div>
        <div className="loader-ring" />
        <p>3D-WELT WIRD GELADEN</p>
      </main>
    );
  }

  return <Game />;
}
