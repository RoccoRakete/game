export type AbilityKind = "boost" | "shield" | "magnet" | "slow" | "emp";
export type MissionKind = "distance" | "checkpoints" | "train" | "parts" | "cargo";
export type PowerKind = string;

export type PowerMeta = {
  id: PowerKind;
  label: string;
  icon: string;
  color: number;
  ability: AbilityKind;
  duration: number;
  strength: number;
  description: string;
};

export type World = {
  name: string;
  subtitle: string;
  mission: string;
  objective: string;
  sky: number;
  fog: number;
  ground: number;
  road: number;
  accent: string;
  icon: string;
  kind: MissionKind;
  target: number;
  secondaryTarget: number;
  biome: number;
  chapter: number;
};

const power = (id: string, label: string, icon: string, color: number, ability: AbilityKind, duration: number, strength: number, description: string): PowerMeta => ({ id, label, icon, color, ability, duration, strength, description });

export const POWER_DEFS: PowerMeta[] = [
  power("canyon-turbo", "Canyon-Turbo", "⚡", 0x16e7ff, "boost", 8, 1.00, "Sofortiger Turboschub und volle Boost-Energie."),
  power("neon-zeitblase", "Neon-Zeitblase", "◷", 0x9d79ff, "slow", 11, 1.00, "Verlangsamt Züge und Hindernisse."),
  power("frostpanzer", "Frostpanzer", "❄", 0x4effa5, "shield", 14, 1.00, "Eisschild gegen den nächsten schweren Treffer."),
  power("lava-magnet", "Lava-Magnet", "🧲", 0xff426c, "magnet", 16, 1.00, "Zieht Münzen und Spezialteile an."),
  power("himmel-emp", "Himmel-EMP", "✦", 0xff62df, "emp", 4, 1.00, "Wirft das Catcher Car weit zurück."),
  power("sandsturm-antrieb", "Sandsturm-Antrieb", "🌪", 0xffb347, "boost", 10, 1.10, "Längerer Turbo mit zusätzlicher Höchstgeschwindigkeit."),
  power("laser-stopp", "Laser-Stopp", "⌁", 0x4bffef, "slow", 12, 1.08, "Friert bewegliche Laserbarrieren fast ein."),
  power("kristall-kuppel", "Kristall-Kuppel", "💎", 0x80ecff, "shield", 16, 1.10, "Stärkerer Kristallschutz für gefährliche Sprünge."),
  power("glut-sog", "Glut-Sog", "☄", 0xff7a24, "magnet", 18, 1.12, "Sammelt Münzen aus besonders großer Entfernung."),
  power("wolken-schock", "Wolken-Schock", "☁", 0xe4f6ff, "emp", 5, 1.12, "Lähmt das Catcher Car und schafft Vorsprung."),
  power("tempel-overdrive", "Tempel-Overdrive", "☀", 0xffd149, "boost", 11, 1.18, "Antiker Sonnenboost mit hoher Beschleunigung."),
  power("holo-freeze", "Holo-Freeze", "◇", 0x35f4ff, "slow", 14, 1.16, "Stoppt Verkehr und Züge beinahe vollständig."),
  power("polar-aegis", "Polar-Aegis", "🛡", 0x9ff8ff, "shield", 18, 1.18, "Hält länger und fängt besonders harte Treffer ab."),
  power("kern-gravitation", "Kern-Gravitation", "◎", 0xff335f, "magnet", 20, 1.20, "Ein Gravitationskern sammelt ganze Münzreihen."),
  power("donner-impuls", "Donner-Impuls", "⚡", 0xfff06a, "emp", 6, 1.20, "Gewitter-EMP mit enormer Rückstoßwelle."),
  power("oasen-nitro", "Oasen-Nitro", "💧", 0x45f5d1, "boost", 12, 1.24, "Kühlt den Motor und verlängert den Nitro-Lauf."),
  power("matrix-bremse", "Matrix-Bremse", "▦", 0x72ff77, "slow", 15, 1.24, "Verlangsamt die komplette Matrix-Stadt."),
  power("gletscher-hülle", "Gletscher-Hülle", "⬡", 0xc8fbff, "shield", 20, 1.26, "Mehrschichtige Hülle aus uraltem Eis."),
  power("magma-orbit", "Magma-Orbit", "●", 0xff4e18, "magnet", 22, 1.28, "Heiße Satelliten ziehen Sammelobjekte heran."),
  power("sturm-emp", "Sturm-EMP", "⛈", 0xaed7ff, "emp", 7, 1.28, "Elektrischer Sturm gegen die gesamte Verfolgung."),
  power("dünen-rakete", "Dünen-Rakete", "🚀", 0xff8c3a, "boost", 13, 1.32, "Raketenstart mit maximaler Spitzengeschwindigkeit."),
  power("quantum-pause", "Quantum-Pause", "⌛", 0xdb70ff, "slow", 17, 1.32, "Dehnt die Zeit rund um das Fahrzeug."),
  power("aurora-schild", "Aurora-Schild", "🌌", 0x57ffbc, "shield", 22, 1.34, "Leuchtender Schutz aus Polarenergie."),
  power("vulkan-vortex", "Vulkan-Vortex", "🌀", 0xff6540, "magnet", 24, 1.36, "Ein Vortex saugt Spezialteile über mehrere Spuren an."),
  power("ionen-kanone", "Ionen-Kanone", "⊕", 0x67b7ff, "emp", 8, 1.36, "Stärkster Langstrecken-Impuls gegen das Catcher Car."),
  power("solar-hyperdrive", "Solar-Hyperdrive", "🌞", 0xffdc45, "boost", 15, 1.42, "Solarenergie für den schnellsten Turbo der Kampagne."),
  power("chrono-kern", "Chrono-Kern", "🕰", 0xb57cff, "slow", 19, 1.42, "Fast vollständiger Zeitstillstand für Hindernisse."),
  power("diamant-festung", "Diamant-Festung", "◆", 0xd9ffff, "shield", 25, 1.44, "Ultimative Panzerung für die Endmissionen."),
  power("galaxie-magnet", "Galaxie-Magnet", "🌠", 0xff78d7, "magnet", 27, 1.46, "Sammelt alles Sichtbare auf der Strecke."),
  power("omega-emp", "Omega-EMP", "Ω", 0xffee7a, "emp", 10, 1.50, "Finaler Impuls mit maximalem Abstand zum Catcher Car."),
];

export const POWER_META: Record<PowerKind, PowerMeta> = Object.fromEntries(POWER_DEFS.map((entry) => [entry.id, entry]));
export const LEVEL_POWER: PowerKind[] = POWER_DEFS.map((entry) => entry.id);

const BASE_COLORS = [
  { sky: 0x70b8d7, fog: 0xe88943, ground: 0xa84622, road: 0x292a2b, accent: "#ff8b2d" },
  { sky: 0x080b2a, fog: 0x311765, ground: 0x15152e, road: 0x171925, accent: "#1dd6d0" },
  { sky: 0x9ed8ec, fog: 0xd8f3ff, ground: 0xddefff, road: 0x394b55, accent: "#55dcff" },
  { sky: 0x2b0d12, fog: 0x6e1d14, ground: 0x271512, road: 0x292526, accent: "#ff5c2a" },
  { sky: 0x6c9fd2, fog: 0xd4d8e5, ground: 0x56525f, road: 0x2a2c35, accent: "#ffd052" },
];

const BLUEPRINTS: Array<[string, string, string, MissionKind]> = [
  ["Sunset Canyon", "Heiße Spur", "🏜️", "distance"], ["Neon Metro", "Kontrollpunkt Null", "🌃", "checkpoints"], ["Frostpass", "Dachläufer", "🏔️", "train"], ["Vulkanhafen", "Verlorene Teile", "🌋", "parts"], ["Himmelsbrücke", "Letzter Konvoi", "🌉", "cargo"],
  ["Sandsturm-Mesa", "Auge des Sturms", "🌪️", "checkpoints"], ["Cyber-Tunnel", "Laserregen", "🛸", "train"], ["Gletschersee", "Dünnes Eis", "🧊", "parts"], ["Magma-Mine", "Roter Schacht", "⛏️", "cargo"], ["Wolkenhafen", "Luftfracht", "☁️", "distance"],
  ["Sonnentempel", "Goldene Flucht", "🛕", "parts"], ["Holo-Distrikt", "Digitale Jagd", "🏙️", "distance"], ["Polar-Nacht", "Nordlicht-Express", "🌌", "train"], ["Kernreaktor", "Kritische Ladung", "☢️", "cargo"], ["Donnerbrücke", "Blitzpunkte", "⛈️", "checkpoints"],
  ["Smaragd-Oase", "Grüner Horizont", "🌴", "distance"], ["Matrix-City", "Code Rot", "💻", "checkpoints"], ["Eis-Kathedrale", "Kristallzug", "🏰", "train"], ["Magma-Orbit", "Feuerringe", "🔥", "parts"], ["Sturm-Zitadelle", "Fracht im Orkan", "🌩️", "cargo"],
  ["Dünen-Metropole", "Raketenstraße", "🏝️", "distance"], ["Quantum-Loop", "Zeitsprung", "⌛", "checkpoints"], ["Aurora-Schlucht", "Lichtschienen", "🌈", "train"], ["Vulkan-Vortex", "Kernstücke", "🌀", "parts"], ["Ionen-Skyway", "Elektrischer Konvoi", "⚛️", "cargo"],
  ["Solar-Wüste", "Hyperdrive", "🌞", "distance"], ["Chrono-Megacity", "Letzte Sekunde", "🕰️", "checkpoints"], ["Diamant-Gletscher", "Unzerbrechlicher Zug", "💎", "train"], ["Galaxie-Krater", "Sternenteile", "🌠", "parts"], ["Omega-Himmelsring", "Finale Fracht", "Ω", "cargo"],
];

const clampByte = (value: number) => Math.max(0, Math.min(255, Math.round(value)));
const shiftColor = (hex: number, shift: number) => {
  const r = clampByte(((hex >> 16) & 255) + shift);
  const g = clampByte(((hex >> 8) & 255) + shift * 0.65);
  const b = clampByte((hex & 255) + shift * 0.35);
  return (r << 16) | (g << 8) | b;
};

const missionName: Record<MissionKind, string> = { distance: "Langstrecken-Flucht", checkpoints: "Kontrollpunkt-Rennen", train: "Zug-Marathon", parts: "Spezialteil-Jagd", cargo: "Gefahrgut-Eskorte" };

export const WORLDS: World[] = BLUEPRINTS.map(([name, code, icon, kind], index) => {
  const biome = index % 5;
  const chapter = Math.floor(index / 5);
  const colors = BASE_COLORS[biome];
  const distanceTarget = 1200 + chapter * 170 + biome * 40;
  const target = kind === "checkpoints" ? 10 + chapter * 2 : kind === "parts" ? 24 + chapter * 3 : distanceTarget;
  const secondaryTarget = kind === "train" ? 12 + chapter * 2 : 0;
  const objective = kind === "distance" ? `Entkomme dem Catcher Car über ${distanceTarget.toLocaleString("de-DE")} Meter.`
    : kind === "checkpoints" ? `Durchfahre ${target} Kontrollpunkte, bevor das Catcher Car dich erreicht.`
      : kind === "train" ? `Springe auf den fahrenden Zug, bleibe ${secondaryTarget} Sekunden oben und schaffe ${distanceTarget.toLocaleString("de-DE")} Meter.`
        : kind === "parts" ? `Sammle ${target} leuchtende Spezialteile zwischen Zügen und Hindernissen.`
          : `Beschütze die gefährliche Fracht über ${distanceTarget.toLocaleString("de-DE")} Meter.`;
  const shift = chapter * 8 - (biome === 1 ? chapter * 2 : 0);
  return {
    name, subtitle: `Mission ${index + 1} · ${code}`, mission: missionName[kind], objective, icon, kind, target, secondaryTarget,
    sky: shiftColor(colors.sky, shift), fog: shiftColor(colors.fog, shift), ground: shiftColor(colors.ground, shift * 0.45), road: colors.road, accent: colors.accent, biome, chapter,
  };
});

export type VehicleItem = { id: string; name: string; price: number; icon: string; scale: [number, number, number]; speedBonus: number };
export type SkinItem = { id: string; name: string; price: number; color: number; accent: string };
export type OutfitItem = { id: string; name: string; price: number; color: number; icon: string };

export const VEHICLES: VehicleItem[] = [
  { id: "street-runner", name: "Street Runner", price: 0, icon: "🏎️", scale: [1, 1, 1], speedBonus: 0 },
  { id: "rail-gt", name: "Rail GT", price: 350, icon: "🚗", scale: [1.08, 0.92, 1.12], speedBonus: 5 },
  { id: "desert-buggy", name: "Desert Buggy", price: 650, icon: "🏜️", scale: [1.12, 1.12, 0.96], speedBonus: 8 },
  { id: "neon-sprint", name: "Neon Sprint", price: 950, icon: "🌃", scale: [0.92, 0.82, 1.16], speedBonus: 12 },
  { id: "frost-4x4", name: "Frost 4x4", price: 1300, icon: "❄️", scale: [1.18, 1.18, 1.04], speedBonus: 7 },
  { id: "volcano-r", name: "Volcano R", price: 1800, icon: "🔥", scale: [1.04, 0.78, 1.22], speedBonus: 16 },
  { id: "sky-hypercar", name: "Sky Hypercar", price: 2500, icon: "⚡", scale: [1.1, 0.72, 1.28], speedBonus: 21 },
  { id: "omega-x", name: "Omega X", price: 4000, icon: "Ω", scale: [1.14, 0.7, 1.34], speedBonus: 28 },
];

export const SKINS: SkinItem[] = [
  { id: "ocean-blue", name: "Ocean Blue", price: 0, color: 0x1288e8, accent: "#37d9ff" }, { id: "racing-red", name: "Racing Red", price: 180, color: 0xe82736, accent: "#ff8c8c" },
  { id: "solar-gold", name: "Solar Gold", price: 260, color: 0xe5a51b, accent: "#ffe78a" }, { id: "neon-lime", name: "Neon Lime", price: 320, color: 0x54d62c, accent: "#b9ff72" },
  { id: "midnight", name: "Midnight", price: 400, color: 0x111827, accent: "#8fa9d9" }, { id: "arctic-white", name: "Arctic White", price: 480, color: 0xe8f5ff, accent: "#aeeeff" },
  { id: "plasma-purple", name: "Plasma Purple", price: 600, color: 0x8a35de, accent: "#d18cff" }, { id: "lava-orange", name: "Lava Orange", price: 700, color: 0xf05b16, accent: "#ffbe66" },
  { id: "chrome", name: "Liquid Chrome", price: 900, color: 0x8ba1ad, accent: "#e9fbff" }, { id: "aurora", name: "Aurora Mint", price: 1100, color: 0x2fd6a6, accent: "#91ffe1" },
  { id: "galaxy", name: "Galaxy Pink", price: 1450, color: 0xd92f9a, accent: "#ff9ee0" }, { id: "omega-black", name: "Omega Black", price: 2000, color: 0x050609, accent: "#ffd95a" },
];

export const OUTFITS: OutfitItem[] = [
  { id: "orange-racer", name: "Orange Racer", price: 0, color: 0xc85b25, icon: "🧥" }, { id: "street-blue", name: "Street Blue", price: 160, color: 0x245bbf, icon: "👕" },
  { id: "neon-pilot", name: "Neon Pilot", price: 260, color: 0x18a88e, icon: "🧑‍🚀" }, { id: "frost-suit", name: "Frost Suit", price: 360, color: 0xb7e8f5, icon: "🥼" },
  { id: "lava-jacket", name: "Lava Jacket", price: 480, color: 0xbd281e, icon: "🧥" }, { id: "shadow-driver", name: "Shadow Driver", price: 620, color: 0x15171d, icon: "🥷" },
  { id: "gold-champion", name: "Gold Champion", price: 850, color: 0xc8941f, icon: "🏆" }, { id: "aurora-suit", name: "Aurora Suit", price: 1100, color: 0x32c59f, icon: "🌌" },
  { id: "galaxy-racer", name: "Galaxy Racer", price: 1500, color: 0x7a33c9, icon: "🌠" }, { id: "omega-legend", name: "Omega Legend", price: 2200, color: 0x29220a, icon: "👑" },
];
