"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { BufferGeometry, Group, InstancedMesh, Material, MeshStandardMaterial, Object3D, WebGLRenderer } from "three";
import { createGameAudio, MUSIC_TRACKS } from "./game-audio";
import type { GameAudio } from "./game-audio";
import { LEVEL_POWER, OUTFITS, POWER_DEFS, POWER_META, SKINS, VEHICLES, WORLDS } from "./game-content";
import type { AbilityKind, PowerKind } from "./game-content";

type Placement = { x: number; y: number; z: number };
type ScrollBatch = { mesh: InstancedMesh; x: number[]; y: number[]; z: Float32Array; wrapAt: number; wrapBy: number };
type ThreeModule = typeof import("three");
let THREE: ThreeModule;

type GameStatus = "menu" | "shop" | "briefing" | "playing" | "paused" | "arresting" | "caught" | "complete" | "won";
type ShopTab = "vehicles" | "skins" | "outfits" | "powerups";

type Hud = {
  distance: number;
  speed: number;
  coins: number;
  boost: number;
  gap: number;
  progress: string;
  timer: number;
  cargo: number;
  active: Partial<Record<PowerKind, number>>;
};

type Spawned = {
  mesh: Object3D;
  kind: "barrier" | "rock" | "oncomingTrain" | "cargoTrain" | "coin" | "part" | "power" | "checkpoint";
  x: number;
  radius: number;
  radiusZ: number;
  value?: PowerKind;
  processed?: boolean;
  spin?: number;
};

type GameApi = {
  startLevel: (level: number) => void;
  showBriefing: (level: number) => void;
  showShop: () => void;
  applyCustomization: (vehicleId: string, skinId: string, outfitId: string) => void;
  restart: () => void;
  next: () => void;
  resetCampaign: () => void;
  pause: () => void;
  resume: () => void;
};

type PendingAction = { type: "showBriefing" | "startLevel"; level: number };
type AudioStatus = "ready" | "playing" | "muted" | "blocked";

const initialHud: Hud = { distance: 0, speed: 0, coins: 0, boost: 64, gap: 28, progress: "0 / 1.200 m", timer: 90, cargo: 100, active: {} };

function loadLocal<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try { const value = window.localStorage.getItem(key); return value ? JSON.parse(value) as T : fallback; } catch { return fallback; }
}

function saveLocal(key: string, value: unknown) {
  try { window.localStorage.setItem(key, JSON.stringify(value)); } catch { /* optional */ }
}

function progressText(world: (typeof WORLDS)[number], distance: number, checkpoints: number, roofTime: number, parts: number, cargo: number) {
  if (world.kind === "distance") return `${Math.min(world.target, Math.floor(distance)).toLocaleString("de-DE")} / ${world.target.toLocaleString("de-DE")} m`;
  if (world.kind === "checkpoints") return `${Math.min(world.target, checkpoints)} / ${world.target} Checkpoints`;
  if (world.kind === "train") return `${Math.min(world.secondaryTarget, roofTime).toFixed(1)} / ${world.secondaryTarget} s · ${Math.min(world.target, Math.floor(distance)).toLocaleString("de-DE")} / ${world.target.toLocaleString("de-DE")} m`;
  if (world.kind === "parts") return `${Math.min(world.target, parts)} / ${world.target} Spezialteile`;
  return `${Math.max(0, Math.ceil(cargo))}% Fracht · ${Math.min(world.target, Math.floor(distance)).toLocaleString("de-DE")} / ${world.target.toLocaleString("de-DE")} m`;
}

function carMesh(color: number, catcher = false) {
  const group = new THREE.Group();
  const paint = new THREE.MeshPhysicalMaterial({ color, metalness: 0.72, roughness: 0.2, clearcoat: 1, clearcoatRoughness: 0.12 });
  paint.name = "car-paint";
  const dark = new THREE.MeshStandardMaterial({ color: 0x090d12, metalness: 0.52, roughness: 0.3 });
  const glass = new THREE.MeshPhysicalMaterial({ color: catcher ? 0x243641 : 0x4ba7d0, metalness: 0.2, roughness: 0.05, transparent: true, opacity: 0.76 });
  const chrome = new THREE.MeshStandardMaterial({ color: 0xbac8d2, metalness: 0.95, roughness: 0.16 });
  const body = new THREE.Mesh(new THREE.BoxGeometry(2.5, 0.55, 4.4), paint);
  body.position.y = 0.55;
  body.castShadow = true;
  group.add(body);
  const hood = new THREE.Mesh(new THREE.BoxGeometry(2.35, 0.35, 1.25), paint);
  hood.position.set(0, 0.82, -1.45);
  hood.castShadow = true;
  group.add(hood);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.85, 0.72, 1.8), glass);
  cabin.position.set(0, 1.12, 0.15);
  cabin.rotation.x = -0.04;
  cabin.castShadow = true;
  group.add(cabin);
  const roof = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.1, 1.74), dark);
  roof.position.set(0, 1.52, 0.12);
  group.add(roof);
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.45, 0.05), glass);
  windshield.position.set(0, 1.18, -0.78);
  windshield.rotation.x = -0.16;
  group.add(windshield);
  for (const side of [-1, 1]) {
    const sideWindow = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.42, 1.08), glass);
    sideWindow.position.set(side * 0.95, 1.18, 0.15);
    group.add(sideWindow);
    const mirror = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.14, 0.3), dark);
    mirror.position.set(side * 1.2, 1.12, -0.52);
    group.add(mirror);
    const skirt = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 3.55), chrome);
    skirt.position.set(side * 1.3, 0.43, 0.08);
    group.add(skirt);
  }
  const spoiler = new THREE.Mesh(new THREE.BoxGeometry(2.35, 0.12, 0.45), dark);
  spoiler.position.set(0, 1.02, 1.87);
  group.add(spoiler);
  for (const x of [-0.85, 0.85]) {
    const post = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.32, 0.12), chrome);
    post.position.set(x, 0.88, 1.87);
    group.add(post);
  }
  const splitter = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.1, 0.36), dark);
  splitter.position.set(0, 0.29, -2.32);
  group.add(splitter);
  const diffuser = splitter.clone();
  diffuser.position.z = 2.32;
  group.add(diffuser);
  const stripeMat = new THREE.MeshBasicMaterial({ color: catcher ? 0x151515 : 0xf2f5ff });
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.58, 4.42), stripeMat);
  stripe.position.set(0, 0.84, 0);
  group.add(stripe);
  const wheelGeo = new THREE.CylinderGeometry(0.48, 0.48, 0.38, 18);
  const rimGeo = new THREE.CylinderGeometry(0.24, 0.24, 0.4, 12);
  for (const x of [-1.3, 1.3]) for (const z of [-1.35, 1.35]) {
    const wheel = new THREE.Mesh(wheelGeo, dark);
    wheel.rotation.z = Math.PI / 2;
    wheel.position.set(x, 0.45, z);
    wheel.castShadow = true;
    const rim = new THREE.Mesh(rimGeo, chrome);
    rim.rotation.z = Math.PI / 2;
    rim.position.copy(wheel.position);
    group.add(wheel, rim);
  }
  const redLight = new THREE.MeshStandardMaterial({ color: 0xff2d2d, emissive: 0xff1028, emissiveIntensity: 3.5 });
  const cyanLight = new THREE.MeshStandardMaterial({ color: 0xdffbff, emissive: 0xbbeeff, emissiveIntensity: 4.2 });
  for (const x of [-0.72, 0.72]) {
    const front = new THREE.Mesh(new THREE.BoxGeometry(0.54, 0.18, 0.08), cyanLight);
    front.position.set(x, 0.7, -2.23);
    group.add(front);
    const rear = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.18, 0.08), redLight);
    rear.position.set(x, 0.72, 2.23);
    group.add(rear);
    const beam = new THREE.Mesh(new THREE.ConeGeometry(0.86, 8, 14, 1, true), new THREE.MeshBasicMaterial({ color: 0xccefff, transparent: true, opacity: 0.055, depthWrite: false, side: THREE.DoubleSide }));
    beam.rotation.x = Math.PI / 2;
    beam.position.set(x, 0.62, -5.95);
    group.add(beam);
  }
  for (const x of [-0.55, 0.55]) {
    const exhaust = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.3, 10), chrome);
    exhaust.rotation.x = Math.PI / 2;
    exhaust.position.set(x, 0.39, 2.35);
    group.add(exhaust);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.9, 12), new THREE.MeshBasicMaterial({ color: 0x4ef4ff, transparent: true, opacity: 0.88 }));
    flame.rotation.x = -Math.PI / 2;
    flame.position.set(x, 0.39, 2.85);
    flame.name = "boost-flame";
    flame.visible = false;
    group.add(flame);
  }
  const underGlow = new THREE.Mesh(new THREE.PlaneGeometry(2.8, 4.4), new THREE.MeshBasicMaterial({ color: catcher ? 0xff253d : 0x19dce8, transparent: true, opacity: 0.18, depthWrite: false, side: THREE.DoubleSide }));
  underGlow.rotation.x = -Math.PI / 2;
  underGlow.position.y = 0.08;
  group.add(underGlow);
  if (catcher) {
    const bar = new THREE.Mesh(new THREE.BoxGeometry(1.7, 0.12, 0.28), dark);
    bar.position.set(0, 1.66, 0.2);
    group.add(bar);
    const red = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.18, 0.34), new THREE.MeshBasicMaterial({ color: 0xff1838 }));
    const blue = red.clone();
    blue.material = new THREE.MeshBasicMaterial({ color: 0x15b8ff });
    red.position.set(-0.46, 1.78, 0.2);
    blue.position.set(0.46, 1.78, 0.2);
    red.name = "police-red";
    blue.name = "police-blue";
    group.add(red, blue);
    for (const x of [-0.85, 0.85]) {
      const upright = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.72, 0.16), chrome);
      upright.position.set(x, 0.62, -2.46);
      group.add(upright);
    }
    const pushBar = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.14, 0.18), chrome);
    pushBar.position.set(0, 0.43, -2.48);
    group.add(pushBar);
    const policeDoor = new THREE.Group();
    policeDoor.name = "police-door";
    policeDoor.position.set(1.22, 0.97, 0.15);
    const doorPanel = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.76, 1.42), paint);
    doorPanel.position.z = 0.48;
    doorPanel.castShadow = true;
    const doorWindow = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.34, 0.82), glass);
    doorWindow.position.set(0.01, 0.45, 0.4);
    policeDoor.add(doorPanel, doorWindow);
    group.add(policeDoor);
  }
  group.scale.setScalar(0.78);
  return group;
}

function trainMesh(cargo = false) {
  const group = new THREE.Group();
  const metal = new THREE.MeshPhysicalMaterial({ color: cargo ? 0x6f3827 : 0x1d2932, metalness: 0.82, roughness: 0.31, clearcoat: 0.34 });
  const trim = new THREE.MeshStandardMaterial({ color: cargo ? 0xe1902e : 0xe9b638, metalness: 0.62, roughness: 0.28 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x080c10, metalness: 0.64, roughness: 0.43 });
  const windowMat = new THREE.MeshStandardMaterial({ color: 0x8be4ff, emissive: 0x2487a2, emissiveIntensity: 1.8, metalness: 0.15, roughness: 0.1 });
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x0a0c0d, metalness: 0.74, roughness: 0.48 });
  const count = cargo ? 3 : 1;
  for (let i = 0; i < count; i++) {
    const car = new THREE.Group();
    const shell = new THREE.Mesh(new THREE.BoxGeometry(3.7, cargo ? 2.7 : 3.3, cargo ? 12 : 9), metal);
    shell.position.y = cargo ? 1.75 : 2.05;
    shell.castShadow = true;
    shell.receiveShadow = true;
    car.add(shell);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(3.9, 0.18, cargo ? 12.2 : 9.2), trim);
    roof.position.y = cargo ? 3.15 : 3.78;
    car.add(roof);
    const underFrame = new THREE.Mesh(new THREE.BoxGeometry(3.35, 0.32, cargo ? 11.3 : 8.3), dark);
    underFrame.position.y = 0.56;
    car.add(underFrame);
    for (const z of cargo ? [-4.3, -2.9, 2.9, 4.3] : [-3.3, 3.3]) {
      const bogie = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.45, 1.3), dark);
      bogie.position.set(0, 0.38, z);
      car.add(bogie);
      for (const x of [-1.45, 1.45]) {
        const wheel = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.22, 16), wheelMat);
        wheel.rotation.z = Math.PI / 2;
        wheel.position.set(x, 0.23, z);
        car.add(wheel);
      }
    }
    if (cargo) {
      for (const side of [-1, 1]) {
        const door = new THREE.Mesh(new THREE.BoxGeometry(0.06, 2.05, 4.6), trim);
        door.position.set(side * 1.88, 1.78, 0);
        car.add(door);
        for (const z of [-4.6, -2.3, 0, 2.3, 4.6]) {
          const rib = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.4, 0.09), dark);
          rib.position.set(side * 1.94, 1.78, z);
          car.add(rib);
        }
      }
    } else {
      for (const side of [-1, 1]) for (let z = -3.1; z <= 3.1; z += 1.25) {
        const window = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.66, 0.82), windowMat);
        window.position.set(side * 1.87, 2.28, z);
        car.add(window);
      }
    }
    car.position.z = i * -12.5;
    group.add(car);
  }
  if (!cargo) {
    const nose = new THREE.Mesh(new THREE.CylinderGeometry(1.55, 1.85, 2.4, 8), trim);
    nose.rotation.x = Math.PI / 2;
    nose.position.set(0, 1.85, -5.35);
    group.add(nose);
    const windshield = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.82, 0.08), windowMat);
    windshield.position.set(0, 2.55, -5.98);
    group.add(windshield);
    for (const x of [-0.9, 0.9]) {
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 10), new THREE.MeshBasicMaterial({ color: 0xffefb4 }));
      lamp.position.set(x, 1.45, -6.08);
      group.add(lamp);
    }
  } else {
    const rampMat = new THREE.MeshStandardMaterial({ color: 0xf4ad2d, metalness: 0.5, roughness: 0.35 });
    const ramp = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.18, 7), rampMat);
    ramp.position.set(0, 1.55, 9.2);
    ramp.rotation.x = -0.42;
    ramp.castShadow = true;
    group.add(ramp);
    for (let i = 0; i < 4; i++) {
      const chevron = new THREE.Mesh(new THREE.BoxGeometry(2.7, 0.05, 0.35), dark);
      chevron.position.set(0, 1.72 + i * 0.3, 11.3 - i * 1.35);
      chevron.rotation.x = -0.42;
      group.add(chevron);
    }
    const beacon = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.13, 0.28, 12), new THREE.MeshStandardMaterial({ color: 0xffb72c, emissive: 0xff6a00, emissiveIntensity: 3 }));
    beacon.position.set(0, 3.45, 7.8);
    group.add(beacon);
  }
  return group;
}

function personMesh(role: "officer" | "driver") {
  const person = new THREE.Group();
  const isOfficer = role === "officer";
  const skin = new THREE.MeshStandardMaterial({ color: isOfficer ? 0xd9a078 : 0xb97852, roughness: 0.78 });
  const cloth = new THREE.MeshPhysicalMaterial({ color: isOfficer ? 0x142b48 : 0xc85b25, roughness: 0.58, clearcoat: 0.12 });
  cloth.name = isOfficer ? "officer-uniform" : "driver-outfit";
  const clothDark = new THREE.MeshStandardMaterial({ color: isOfficer ? 0x081522 : 0x28282c, roughness: 0.68 });
  const black = new THREE.MeshStandardMaterial({ color: 0x080a0d, metalness: 0.22, roughness: 0.45 });
  const badgeMat = new THREE.MeshStandardMaterial({ color: 0xf3c94d, emissive: 0x7b4d00, emissiveIntensity: 0.45, metalness: 0.78, roughness: 0.22 });
  const cuffMetal = new THREE.MeshStandardMaterial({ color: 0xdce9ef, metalness: 1, roughness: 0.1, envMapIntensity: 1.4 });

  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.68, 0.9, 0.38), cloth);
  torso.position.y = 1.38;
  torso.castShadow = true;
  person.add(torso);
  const waist = new THREE.Mesh(new THREE.BoxGeometry(0.72, 0.16, 0.42), black);
  waist.position.y = 0.92;
  person.add(waist);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.27, 18, 14), skin);
  head.position.y = 2.04;
  head.castShadow = true;
  person.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.275, 16, 8, 0, Math.PI * 2, 0, Math.PI * 0.52), clothDark);
  hair.position.y = 2.09;
  person.add(hair);

  for (const side of [-1, 1]) {
    const arm = new THREE.Group();
    arm.name = side < 0 ? `${role}-left-arm` : `${role}-right-arm`;
    arm.position.set(side * 0.46, 1.72, 0);
    const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.7, 0.25), cloth);
    sleeve.position.y = -0.34;
    sleeve.castShadow = true;
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 8), skin);
    hand.name = side < 0 ? `${role}-left-hand` : `${role}-right-hand`;
    hand.position.y = -0.76;
    arm.add(sleeve, hand);
    if (!isOfficer) {
      const wristCuff = new THREE.Group();
      wristCuff.name = side < 0 ? "driver-left-cuff" : "driver-right-cuff";
      wristCuff.position.y = -0.68;
      wristCuff.visible = false;
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.028, 10, 24), cuffMetal);
      ring.rotation.x = Math.PI / 2;
      ring.castShadow = true;
      const lock = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.09, 0.075), cuffMetal);
      lock.position.set(side < 0 ? 0.11 : -0.11, 0, 0);
      lock.castShadow = true;
      wristCuff.add(ring, lock);
      arm.add(wristCuff);
    }
    person.add(arm);
    const leg = new THREE.Group();
    leg.name = side < 0 ? `${role}-left-leg` : `${role}-right-leg`;
    leg.position.set(side * 0.2, 0.88, 0);
    const trouser = new THREE.Mesh(new THREE.BoxGeometry(0.27, 0.82, 0.3), clothDark);
    trouser.position.y = -0.4;
    trouser.castShadow = true;
    const shoe = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.16, 0.48), black);
    shoe.position.set(0, -0.84, -0.08);
    leg.add(trouser, shoe);
    person.add(leg);
  }

  if (isOfficer) {
    const vest = new THREE.Mesh(new THREE.BoxGeometry(0.73, 0.66, 0.44), new THREE.MeshStandardMaterial({ color: 0x213a52, roughness: 0.52 }));
    vest.position.set(0, 1.45, -0.02);
    person.add(vest);
    const patchCanvas = document.createElement("canvas");
    patchCanvas.width = 256;
    patchCanvas.height = 64;
    const patchContext = patchCanvas.getContext("2d");
    if (patchContext) {
      patchContext.fillStyle = "#e7f4ff";
      patchContext.fillRect(0, 0, 256, 64);
      patchContext.fillStyle = "#102943";
      patchContext.font = "900 38px Arial";
      patchContext.textAlign = "center";
      patchContext.textBaseline = "middle";
      patchContext.fillText("POLIZEI", 128, 34);
    }
    const patchTexture = new THREE.CanvasTexture(patchCanvas);
    patchTexture.colorSpace = THREE.SRGBColorSpace;
    const policePatch = new THREE.Mesh(new THREE.PlaneGeometry(0.48, 0.13), new THREE.MeshBasicMaterial({ map: patchTexture }));
    policePatch.position.set(0, 1.58, -0.246);
    policePatch.rotation.y = Math.PI;
    person.add(policePatch);
    const badge = new THREE.Mesh(new THREE.OctahedronGeometry(0.095, 0), badgeMat);
    badge.position.set(-0.2, 1.65, -0.26);
    person.add(badge);
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.3, 0.16, 16), clothDark);
    cap.position.y = 2.29;
    person.add(cap);
    const brim = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.05, 0.28), clothDark);
    brim.position.set(0, 2.23, -0.17);
    person.add(brim);
    const holster = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.3, 0.18), black);
    holster.position.set(0.42, 0.78, 0);
    person.add(holster);
  } else {
    const hood = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.56), cloth);
    hood.position.set(0, 1.96, 0.08);
    person.add(hood);
  }
  person.scale.setScalar(0.92);
  return person;
}

export default function CatcherCarGame() {
  const mountRef = useRef<HTMLDivElement>(null);
  const apiRef = useRef<GameApi | null>(null);
  const audioRef = useRef<GameAudio | null>(null);
  const pendingActionRef = useRef<PendingAction | null>(null);
  const keysRef = useRef<Record<string, boolean>>({});
  const statusRef = useRef<GameStatus>("menu");
  const levelRef = useRef(0);
  const powerUpgradesRef = useRef<Record<string, number>>({});
  const equipmentRef = useRef({ vehicle: "street-runner", skin: "ocean-blue", outfit: "orange-racer" });
  const [status, setStatus] = useState<GameStatus>("menu");
  const [level, setLevel] = useState(0);
  const [hud, setHud] = useState<Hud>(initialHud);
  const [soundOn, setSoundOn] = useState(true);
  const [audioStatus, setAudioStatus] = useState<AudioStatus>("ready");
  const [engineReady, setEngineReady] = useState(false);
  const [engineFailed, setEngineFailed] = useState(false);
  const [arrestCaption, setArrestCaption] = useState("CATCHER CAR HAT DICH EINGEHOLT");
  const [shopTab, setShopTab] = useState<ShopTab>("vehicles");
  const [shopMessage, setShopMessage] = useState("Wähle deine Ausrüstung");
  const [wallet, setWallet] = useState(() => loadLocal("rail-rush-wallet", 500));
  const [ownedVehicles, setOwnedVehicles] = useState<string[]>(() => loadLocal("rail-rush-owned-vehicles", ["street-runner"]));
  const [ownedSkins, setOwnedSkins] = useState<string[]>(() => loadLocal("rail-rush-owned-skins", ["ocean-blue"]));
  const [ownedOutfits, setOwnedOutfits] = useState<string[]>(() => loadLocal("rail-rush-owned-outfits", ["orange-racer"]));
  const [selectedVehicle, setSelectedVehicle] = useState(() => loadLocal("rail-rush-selected-vehicle", "street-runner"));
  const [selectedSkin, setSelectedSkin] = useState(() => loadLocal("rail-rush-selected-skin", "ocean-blue"));
  const [selectedOutfit, setSelectedOutfit] = useState(() => loadLocal("rail-rush-selected-outfit", "orange-racer"));
  const [powerUpgrades, setPowerUpgrades] = useState<Record<string, number>>(() => loadLocal("rail-rush-power-upgrades", {}));
  const [unlockedLevel, setUnlockedLevel] = useState(() => {
    if (typeof window === "undefined") return 0;
    try { return Math.min(WORLDS.length - 1, Math.max(0, Number(window.localStorage.getItem("rail-rush-unlocked") ?? 0))); } catch { return 0; }
  });
  const [bestCoins, setBestCoins] = useState(() => {
    if (typeof window === "undefined") return 0;
    try { return Math.max(0, Number(window.localStorage.getItem("rail-rush-best-coins") ?? 0)); } catch { return 0; }
  });

  const changeStatus = useCallback((value: GameStatus) => {
    statusRef.current = value;
    setStatus(value);
  }, []);

  const startMusic = useCallback(async (index: number) => {
    if (!audioRef.current) audioRef.current = createGameAudio();
    audioRef.current.setMuted(!soundOn);
    const started = await audioRef.current.startTrack(index);
    setAudioStatus(!soundOn ? "muted" : started ? "playing" : "blocked");
  }, [soundOn]);

  const toggleSound = () => {
    setSoundOn((currentValue) => {
      const nextValue = !currentValue;
      if (!audioRef.current && nextValue) audioRef.current = createGameAudio();
      audioRef.current?.setMuted(!nextValue);
      if (!nextValue) setAudioStatus("muted");
      if (nextValue && (statusRef.current === "playing" || statusRef.current === "briefing")) {
        void audioRef.current?.startTrack(levelRef.current).then((started) => setAudioStatus(started ? "playing" : "blocked"));
      }
      return nextValue;
    });
  };

  const recordProgress = useCallback((completedLevel: number, coinCount: number) => {
    const nextUnlocked = Math.min(WORLDS.length - 1, completedLevel + 1);
    setUnlockedLevel((currentValue) => {
      const nextValue = Math.max(currentValue, nextUnlocked);
      try { window.localStorage.setItem("rail-rush-unlocked", String(nextValue)); } catch { /* optional */ }
      return nextValue;
    });
    setBestCoins((currentValue) => {
      const nextValue = Math.max(currentValue, coinCount);
      try { window.localStorage.setItem("rail-rush-best-coins", String(nextValue)); } catch { /* optional */ }
      return nextValue;
    });
    setWallet((currentValue) => {
      const reward = 100 + completedLevel * 8 + Math.max(0, coinCount);
      const nextValue = currentValue + reward;
      saveLocal("rail-rush-wallet", nextValue);
      return nextValue;
    });
  }, []);

  useEffect(() => {
    powerUpgradesRef.current = powerUpgrades;
  }, [powerUpgrades]);

  useEffect(() => {
    equipmentRef.current = { vehicle: selectedVehicle, skin: selectedSkin, outfit: selectedOutfit };
    apiRef.current?.applyCustomization(selectedVehicle, selectedSkin, selectedOutfit);
  }, [selectedVehicle, selectedSkin, selectedOutfit, engineReady]);

  useEffect(() => {
    let disposed = false;
    let cleanup: (() => void) | undefined;
    const activateEngine = () => {
      if (disposed) return;
      setEngineReady(true);
      const pending = pendingActionRef.current;
      pendingActionRef.current = null;
      if (pending?.type === "showBriefing") apiRef.current?.showBriefing(pending.level);
      if (pending?.type === "startLevel") apiRef.current?.startLevel(pending.level);
    };
    const boot = async () => {
    if (!mountRef.current) return;
    THREE = await import("three");
    if (disposed || !mountRef.current) return;
    const host = mountRef.current;
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(WORLDS[0].sky);
    scene.fog = new THREE.Fog(WORLDS[0].fog, 45, 210);
    const camera = new THREE.PerspectiveCamera(58, host.clientWidth / host.clientHeight, 0.1, 500);
    camera.position.set(0, 6.4, 15.2);
    camera.lookAt(0, 1.1, -12);
    let renderer: WebGLRenderer;
    try {
      const webglProbe = document.createElement("canvas");
      if (!webglProbe.getContext("webgl2") && !webglProbe.getContext("webgl")) throw new Error("webgl-unavailable");
      renderer = new THREE.WebGLRenderer({ antialias: window.devicePixelRatio <= 1, powerPreference: "high-performance" });
    } catch {
      const fallback = document.createElement("canvas");
      fallback.className = "fallback-canvas";
      host.appendChild(fallback);
      const context = fallback.getContext("2d");
      if (!context) return;
      let fallbackRaf = 0;
      let fallbackLast = performance.now();
      let fLevel = 0;
      let fDistance = 0;
      let fSpeed = 0;
      let fGap = 28;
      let fBoost = 64;
      let fCoins = 0;
      let fX = 0;
      let fPhase = 0;
      let fArrestTime = 0;

      const resizeFallback = () => {
        fallback.width = Math.max(1, Math.floor(host.clientWidth * Math.min(1.5, window.devicePixelRatio)));
        fallback.height = Math.max(1, Math.floor(host.clientHeight * Math.min(1.5, window.devicePixelRatio)));
        fallback.style.width = `${host.clientWidth}px`;
        fallback.style.height = `${host.clientHeight}px`;
      };
      const fallbackProgress = () => {
        const world = WORLDS[fLevel];
        return progressText(world, fDistance, Math.floor(fDistance / 90), fDistance / 72, Math.floor(fDistance / 43), Math.max(10, 100 - fDistance / 24));
      };
      const resetFallback = (index: number, nextStatus: GameStatus) => {
        fLevel = index;
        levelRef.current = index;
        setLevel(index);
        fDistance = 0;
        fSpeed = nextStatus === "playing" ? 72 : 0;
        fGap = 28;
        fBoost = Math.max(fBoost, 64);
        fX = 0;
        fArrestTime = 0;
        changeStatus(nextStatus);
        setHud({ ...initialHud, coins: fCoins, boost: fBoost, progress: index === 0 ? "0 / 1.200 m" : fallbackProgress() });
      };
      apiRef.current = {
        startLevel(index) { resetFallback(index, "playing"); },
        showBriefing(index) { resetFallback(index, "briefing"); },
        showShop() { resetFallback(fLevel, "shop"); },
        applyCustomization() { /* 2D fallback keeps a simplified vehicle */ },
        restart() { resetFallback(fLevel, "playing"); },
        next() { resetFallback(Math.min(WORLDS.length - 1, fLevel + 1), "briefing"); },
        resetCampaign() { fCoins = 0; fBoost = 64; resetFallback(0, "menu"); },
        pause() { if (statusRef.current === "playing") { audioRef.current?.pause(); changeStatus("paused"); } },
        resume() { if (statusRef.current === "paused") { audioRef.current?.resume(); changeStatus("playing"); } },
      };
      activateEngine();
      const fallbackDown = (event: KeyboardEvent) => {
        const key = event.key.toLowerCase();
        keysRef.current[key] = true;
        if (key === "escape") {
          if (statusRef.current === "playing") apiRef.current?.pause();
          else if (statusRef.current === "paused") apiRef.current?.resume();
        }
      };
      const fallbackUp = (event: KeyboardEvent) => { keysRef.current[event.key.toLowerCase()] = false; };
      window.addEventListener("keydown", fallbackDown);
      window.addEventListener("keyup", fallbackUp);
      window.addEventListener("resize", resizeFallback);
      resizeFallback();

      const drawCar2d = (x: number, y: number, scale: number, color: string, police = false) => {
        context.save();
        context.translate(x, y);
        context.scale(scale, scale);
        context.fillStyle = "#071018";
        context.fillRect(-46, -10, 92, 34);
        context.fillStyle = color;
        context.beginPath();
        context.moveTo(-42, 14); context.lineTo(-34, -19); context.lineTo(-20, -31); context.lineTo(22, -31); context.lineTo(38, -16); context.lineTo(46, 14); context.closePath(); context.fill();
        context.fillStyle = "#16384c"; context.fillRect(-20, -26, 40, 15);
        context.fillStyle = police ? "#151515" : "#f3f5ff"; context.fillRect(-3, -31, 6, 46);
        context.fillStyle = "#ff303b"; context.fillRect(-34, 7, 18, 5); context.fillRect(16, 7, 18, 5);
        if (police) { context.fillStyle = Math.sin(fPhase * 12) > 0 ? "#ff1b37" : "#15b8ff"; context.fillRect(-16, -39, 32, 7); }
        context.restore();
      };
      const renderFallback = (now: number) => {
        const dt = Math.min(.04, (now - fallbackLast) / 1000);
        fallbackLast = now;
        fPhase += dt;
        const w = fallback.width;
        const h = fallback.height;
        const dpr = Math.min(1.5, window.devicePixelRatio);
        const keys = keysRef.current;
        if (statusRef.current === "playing") {
          const boostHeld = !!keys.shift && fBoost > 0;
          fSpeed += (keys.w || keys.arrowup ? 76 : -14) * dt;
          if (keys.s || keys.arrowdown) fSpeed -= 90 * dt;
          if (boostHeld) { fSpeed += 120 * dt; fBoost = Math.max(0, fBoost - 24 * dt); }
          else fBoost = Math.min(100, fBoost + 3 * dt);
          fSpeed = Math.max(38, Math.min(boostHeld ? 240 : 178, fSpeed));
          fX += ((keys.a || keys.arrowleft ? -1 : 0) + (keys.d || keys.arrowright ? 1 : 0)) * dt * 390;
          fX = Math.max(-w * .30, Math.min(w * .30, fX));
          fDistance += fSpeed * .2 * dt;
          fGap += ((fSpeed - 110) * .006 - .22) * dt;
          fGap = Math.max(0, Math.min(40, fGap));
          if (fGap <= 0) {
            fArrestTime = 0;
            setArrestCaption("CATCHER CAR HAT DICH EINGEHOLT");
            audioRef.current?.caught();
            changeStatus("arresting");
          }
          const fallbackWorld = WORLDS[fLevel];
          const target = fallbackWorld.kind === "checkpoints" ? fallbackWorld.target * 90 : fallbackWorld.kind === "parts" ? fallbackWorld.target * 43 : fallbackWorld.target;
          if (fDistance >= target) {
            recordProgress(fLevel, fCoins);
            changeStatus(fLevel === WORLDS.length - 1 ? "won" : "complete");
          }
          setHud({ distance: fDistance, speed: fSpeed, coins: fCoins, boost: fBoost, gap: fGap, progress: fallbackProgress(), timer: Math.max(0, 90 - fDistance / 12), cargo: Math.max(10, 100 - fDistance / 24), active: {} });
        } else if (statusRef.current === "arresting") {
          fArrestTime += dt;
          if (fArrestTime > .75 && fArrestTime < .8) setArrestCaption("POLIZIST STEIGT AUS");
          if (fArrestTime > 2.15 && fArrestTime < 2.2) setArrestCaption("FLUCHTFAHRER STEIGT AUS");
          if (fArrestTime > 3.35 && fArrestTime < 3.4) setArrestCaption("HÄNDE HINTER DEN RÜCKEN");
          if (fArrestTime > 5.15 && fArrestTime < 5.2) { setArrestCaption("HANDSCHELLEN ANGELEGT"); audioRef.current?.handcuffs(); }
          if (fArrestTime > 6.25 && fArrestTime < 6.3) setArrestCaption("FAHRER WIRD ABGEFÜHRT");
          if (fArrestTime >= 8.75) changeStatus("caught");
        }
        const world = WORLDS[fLevel];
        const grad = context.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, `#${world.sky.toString(16).padStart(6, "0")}`);
        grad.addColorStop(.52, `#${world.fog.toString(16).padStart(6, "0")}`);
        grad.addColorStop(1, `#${world.ground.toString(16).padStart(6, "0")}`);
        context.fillStyle = grad; context.fillRect(0, 0, w, h);
        const horizon = h * .34;
        context.fillStyle = `#${world.road.toString(16).padStart(6, "0")}`;
        context.beginPath(); context.moveTo(w * .42, horizon); context.lineTo(w * .58, horizon); context.lineTo(w * .94, h); context.lineTo(w * .06, h); context.closePath(); context.fill();
        context.strokeStyle = world.biome === 1 ? "#1dd6d0" : "#f0b03b"; context.lineWidth = 4 * dpr;
        context.beginPath(); context.moveTo(w * .42, horizon); context.lineTo(w * .06, h); context.moveTo(w * .58, horizon); context.lineTo(w * .94, h); context.stroke();
        for (let i = 0; i < 9; i++) {
          const p = ((i / 9 + fPhase * fSpeed * .0007) % 1);
          const y = horizon + Math.pow(p, 1.8) * (h - horizon);
          const half = 3 + p * w * .31;
          context.strokeStyle = "#f7d593aa"; context.lineWidth = Math.max(1, p * 6 * dpr);
          context.beginPath(); context.moveTo(w / 2 - half * .34, y); context.lineTo(w / 2 - half * .27, y + 12 * p); context.moveTo(w / 2 + half * .34, y); context.lineTo(w / 2 + half * .27, y + 12 * p); context.stroke();
        }
        const trainY = horizon + h * .18;
        context.fillStyle = "#713a25"; context.fillRect(w * .67, trainY, w * .25, h * .16);
        context.fillStyle = "#f0ae31"; context.beginPath(); context.moveTo(w * .67, trainY + h * .16); context.lineTo(w * .59, trainY + h * .3); context.lineTo(w * .72, trainY + h * .3); context.lineTo(w * .77, trainY + h * .16); context.fill();
        context.fillStyle = "#222a2d"; context.fillRect(w * .23, horizon + h * .07, w * .11, h * .17);
        drawCar2d(w / 2 + fX * .35, h * .78, 1.3 * dpr, "#1288e8");
        drawCar2d(w / 2 - w * .11 + fX * .25, h * .88, (1.03 + (28 - fGap) * .012) * dpr, "#ef3340", true);
        if (statusRef.current === "arresting" && fArrestTime > 1.1) {
          const officerX = w / 2 - w * .08 + Math.min(1, (fArrestTime - 1.1) / 2) * w * .14;
          context.fillStyle = "#f0bd97"; context.beginPath(); context.arc(officerX, h * .7, 9 * dpr, 0, Math.PI * 2); context.fill();
          context.fillStyle = "#152d4a"; context.fillRect(officerX - 11 * dpr, h * .71, 22 * dpr, 48 * dpr);
          context.fillStyle = "#f2d04f"; context.fillRect(officerX - 3 * dpr, h * .725, 6 * dpr, 7 * dpr);
          if (fArrestTime > 3.05) {
            const driverX = w / 2 + w * .05;
            context.fillStyle = "#d59b76"; context.beginPath(); context.arc(driverX, h * .705, 9 * dpr, 0, Math.PI * 2); context.fill();
            context.fillStyle = "#d16b2f"; context.fillRect(driverX - 11 * dpr, h * .715, 22 * dpr, 46 * dpr);
          }
        }
        fallbackRaf = requestAnimationFrame(renderFallback);
      };
      fallbackRaf = requestAnimationFrame(renderFallback);
      return () => {
        cancelAnimationFrame(fallbackRaf);
        window.removeEventListener("resize", resizeFallback);
        window.removeEventListener("keydown", fallbackDown);
        window.removeEventListener("keyup", fallbackUp);
        if (host.contains(fallback)) host.removeChild(fallback);
        apiRef.current = null;
      };
    }
    // Dynamische Auflösung: fällt die Framerate dauerhaft unter ~48 fps, wird die Render-Auflösung schrittweise gesenkt.
    let pixelRatio = Math.min(window.devicePixelRatio, 1.5);
    let avgFrameMs = 16.7;
    let adaptCooldown = 3000;
    renderer.setPixelRatio(pixelRatio);
    renderer.setSize(host.clientWidth, host.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.12;
    host.appendChild(renderer.domElement);

    const hemi = new THREE.HemisphereLight(0xffe4c0, 0x492015, 2.8);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight(0xffd1a0, 5.2);
    sun.position.set(-18, 34, 12);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    sun.shadow.bias = -0.0002;
    sun.shadow.normalBias = 0.025;
    sun.shadow.camera.left = -30;
    sun.shadow.camera.right = 30;
    sun.shadow.camera.top = 35;
    sun.shadow.camera.bottom = -25;
    scene.add(sun);

    const worldRoot = new THREE.Group();
    const objectRoot = new THREE.Group();
    scene.add(worldRoot, objectRoot);
    const player = carMesh(0x1288e8);
    player.position.set(0, 0.02, 5);
    scene.add(player);
    const boostFlames: Object3D[] = [];
    player.traverse((node) => { if (node.name === "boost-flame") boostFlames.push(node); });
    const catcher = carMesh(0xf22635, true);
    catcher.position.set(-1.8, 0, 10.2);
    scene.add(catcher);
    const officer = personMesh("officer");
    const fugitive = personMesh("driver");
    officer.visible = false;
    fugitive.visible = false;
    scene.add(officer, fugitive);
    const policeDoor = catcher.getObjectByName("police-door");
    const driverLeftArm = fugitive.getObjectByName("driver-left-arm");
    const driverRightArm = fugitive.getObjectByName("driver-right-arm");
    const driverLeftLeg = fugitive.getObjectByName("driver-left-leg");
    const driverRightLeg = fugitive.getObjectByName("driver-right-leg");
    const driverLeftCuff = fugitive.getObjectByName("driver-left-cuff");
    const driverRightCuff = fugitive.getObjectByName("driver-right-cuff");
    const officerLeftArm = officer.getObjectByName("officer-left-arm");
    const officerRightArm = officer.getObjectByName("officer-right-arm");
    const officerLeftLeg = officer.getObjectByName("officer-left-leg");
    const officerRightLeg = officer.getObjectByName("officer-right-leg");
    const cuffChain = new THREE.Mesh(
      new THREE.CylinderGeometry(0.026, 0.026, 0.22, 10),
      new THREE.MeshStandardMaterial({ color: 0xe5f0f5, metalness: 1, roughness: 0.09 }),
    );
    cuffChain.name = "handcuff-chain";
    cuffChain.castShadow = true;
    cuffChain.visible = false;
    scene.add(cuffChain);
    const cuffLeftWorld = new THREE.Vector3();
    const cuffRightWorld = new THREE.Vector3();
    const cuffMidWorld = new THREE.Vector3();
    const cuffDirection = new THREE.Vector3();
    const cuffYAxis = new THREE.Vector3(0, 1, 0);

    // Gemeinsamer Glow statt PointLight pro Sammelobjekt: konstante Lichtanzahl, keine Shader-Neukompilierung.
    const glowGeometry = new THREE.SphereGeometry(1.1, 12, 8);
    glowGeometry.userData.shared = true;
    const glowMaterials = new Map<number, import("three").MeshBasicMaterial>();
    // Statische bzw. scrollende Dekoration als InstancedMesh: ein Draw Call statt hunderter Einzel-Meshes.
    const instanceMatrix = new THREE.Matrix4();
    function createInstanced(geometry: BufferGeometry, material: Material, placements: Placement[]) {
      const mesh = new THREE.InstancedMesh(geometry, material, placements.length);
      placements.forEach((p, i) => mesh.setMatrixAt(i, instanceMatrix.makeTranslation(p.x, p.y, p.z)));
      mesh.instanceMatrix.needsUpdate = true;
      mesh.frustumCulled = false;
      return mesh;
    }
    function addScrollBatch(geometry: BufferGeometry, material: Material, placements: Placement[], wrapAt: number, wrapBy: number) {
      const mesh = createInstanced(geometry, material, placements);
      worldRoot.add(mesh);
      scrollBatches.push({ mesh, x: placements.map((p) => p.x), y: placements.map((p) => p.y), z: Float32Array.from(placements, (p) => p.z), wrapAt, wrapBy });
    }
    function scrollBatch(batch: ScrollBatch, delta: number) {
      for (let i = 0; i < batch.z.length; i++) {
        let z = batch.z[i] + delta;
        if (z > batch.wrapAt) z -= batch.wrapBy;
        batch.z[i] = z;
        batch.mesh.setMatrixAt(i, instanceMatrix.makeTranslation(batch.x[i], batch.y[i], z));
      }
      batch.mesh.instanceMatrix.needsUpdate = true;
    }
    const disposeNode = (node: Object3D) => {
      if (!(node instanceof THREE.Mesh || node instanceof THREE.Points)) return;
      if (node instanceof THREE.InstancedMesh) node.dispose();
      if (!node.geometry.userData.shared) node.geometry.dispose();
      const materials = Array.isArray(node.material) ? node.material : [node.material];
      materials.forEach((m) => {
        if (m.userData.shared) return;
        (m as MeshStandardMaterial).map?.dispose();
        m.dispose();
      });
    };

    let roadMat: MeshStandardMaterial;
    let groundMat: MeshStandardMaterial;
    let scrollBatches: ScrollBatch[] = [];
    let scenery: Object3D[] = [];
    let weatherSystem: import("three").Points | null = null;
    let objects: Spawned[] = [];
    let levelIndex = 0;
    let elapsed = 0;
    let distance = 0;
    let speed = 0;
    let coins = 0;
    let boost = 64;
    let gap = 28;
    let playerX = 0;
    let playerY = 0.02;
    let playerVY = 0;
    let onTrain = false;
    let spawnClock = 0;
    let spawnCount = 0;
    let checkpoints = 0;
    let roofTime = 0;
    let parts = 0;
    let cargo = 100;
    let hudClock = 0;
    let shake = 0;
    let arrestTime = 0;
    let arrestPhase = -1;
    let active: Partial<Record<PowerKind, number>> = {};
    let last = performance.now();
    let raf = 0;

    function clearGroup(group: Group) {
      while (group.children.length) {
        const child = group.children.pop();
        if (!child) continue;
        child.traverse(disposeNode);
      }
    }

    function rebuildWorld(index: number) {
      clearGroup(worldRoot);
      scrollBatches = [];
      scenery = [];
      weatherSystem = null;
      const world = WORLDS[index];
      const biome = world.biome;
      const chapter = world.chapter;
      const skyTops = [0x16527a, 0x020417, 0x4b8fc1, 0x14040a, 0x366da5];
      const skyBottoms = [0xff9a4f, 0x35104f, 0xe8f8ff, 0x9a2a16, 0xe8c4af];
      const sunColors = [0xffd09a, 0x8cf7ff, 0xe5f7ff, 0xff6534, 0xffe2bd];
      scene.background = new THREE.Color(world.sky);
      scene.fog = new THREE.Fog(world.fog, biome === 1 ? 50 - chapter : 62 - chapter, biome === 1 ? 225 : 260);
      hemi.color.setHex(biome === 1 ? 0x6d72ff : biome === 3 ? 0xff8a58 : 0xffe8d2);
      hemi.groundColor.setHex(biome === 2 ? 0x68869a : biome === 1 ? 0x160c35 : 0x3b2118);
      hemi.intensity = biome === 1 ? 2.2 : 2.9;
      sun.color.setHex(sunColors[biome]);
      sun.intensity = (biome === 1 ? 3.2 : biome === 3 ? 5.8 : 4.8) + chapter * 0.12;
      sun.position.set(biome === 0 ? -24 + chapter * 4 : 18, biome === 1 ? 26 : 38, biome === 3 ? -8 : 15);
      renderer.toneMappingExposure = biome === 1 ? 1.2 : biome === 3 ? 1.05 : 1.12;

      const skyDome = new THREE.Mesh(
        new THREE.SphereGeometry(240, 32, 18),
        new THREE.ShaderMaterial({
          uniforms: { topColor: { value: new THREE.Color(skyTops[biome]).offsetHSL(chapter * 0.018, 0, 0) }, bottomColor: { value: new THREE.Color(skyBottoms[biome]).offsetHSL(chapter * 0.012, 0, chapter * 0.01) } },
          vertexShader: "varying vec3 vPos; void main(){ vPos=position; gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0); }",
          fragmentShader: "uniform vec3 topColor; uniform vec3 bottomColor; varying vec3 vPos; void main(){ float h=smoothstep(-0.18,0.62,normalize(vPos).y); gl_FragColor=vec4(mix(bottomColor,topColor,h),1.0); }",
          side: THREE.BackSide,
          depthWrite: false,
        }),
      );
      worldRoot.add(skyDome);

      const roadCanvas = document.createElement("canvas");
      roadCanvas.width = 256;
      roadCanvas.height = 512;
      const roadContext = roadCanvas.getContext("2d");
      if (roadContext) {
        const base = `#${world.road.toString(16).padStart(6, "0")}`;
        roadContext.fillStyle = base;
        roadContext.fillRect(0, 0, 256, 512);
        for (let i = 0; i < 1100; i++) {
          const shade = biome === 1 ? 38 + Math.random() * 34 : 30 + Math.random() * 35;
          roadContext.fillStyle = `rgba(${shade},${shade},${shade},${0.12 + Math.random() * 0.22})`;
          const size = 0.5 + Math.random() * 2.2;
          roadContext.fillRect(Math.random() * 256, Math.random() * 512, size, size);
        }
        roadContext.strokeStyle = biome === 1 ? "rgba(30,220,220,.11)" : "rgba(8,8,8,.16)";
        roadContext.lineWidth = 2;
        for (let i = 0; i < 14; i++) {
          roadContext.beginPath();
          roadContext.moveTo(Math.random() * 256, Math.random() * 512);
          roadContext.lineTo(Math.random() * 256, Math.random() * 512);
          roadContext.stroke();
        }
      }
      const roadTexture = new THREE.CanvasTexture(roadCanvas);
      roadTexture.wrapS = THREE.RepeatWrapping;
      roadTexture.wrapT = THREE.RepeatWrapping;
      roadTexture.repeat.set(3, 48);
      roadTexture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
      roadTexture.colorSpace = THREE.SRGBColorSpace;
      groundMat = new THREE.MeshStandardMaterial({ color: world.ground, roughness: 0.92 });
      roadMat = new THREE.MeshStandardMaterial({ color: 0xffffff, map: roadTexture, roughness: biome === 1 ? 0.5 : 0.86, metalness: biome === 1 ? 0.32 : 0.04 });
      const ground = new THREE.Mesh(new THREE.PlaneGeometry(110, 470), groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.position.set(0, -0.18, -185);
      ground.receiveShadow = true;
      worldRoot.add(ground);
      const road = new THREE.Mesh(new THREE.PlaneGeometry(20, 450), roadMat);
      road.rotation.x = -Math.PI / 2;
      road.position.set(0, -0.1, -185);
      road.receiveShadow = true;
      worldRoot.add(road);
      const edgeMat = new THREE.MeshStandardMaterial({ color: biome === 1 ? 0x1dd6d0 : 0xf0a82e, emissive: biome === 1 ? 0x1dd6d0 : 0x7a3800, emissiveIntensity: biome === 1 ? 1.2 : 0.24 });
      for (const x of [-9.75, 9.75]) {
        const edge = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.16, 450), edgeMat);
        edge.position.set(x, 0.02, -185);
        worldRoot.add(edge);
      }
      const lineMat = new THREE.MeshBasicMaterial({ color: biome === 1 ? 0x38ffe2 : 0xf7d593 });
      const linePlacements: Placement[] = [];
      for (let z = -380; z < 28; z += 13) for (const x of [-3.35, 3.35]) linePlacements.push({ x, y: 0.01, z });
      addScrollBatch(new THREE.BoxGeometry(0.12, 0.04, 5), lineMat, linePlacements, 30, 405);
      const railMat = new THREE.MeshStandardMaterial({ color: 0xb7a68c, metalness: 0.8, roughness: 0.3 });
      for (const x of [5.25, 7.15]) {
        const rail = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.18, 430), railMat);
        rail.position.set(x, 0.03, -175);
        worldRoot.add(rail);
      }
      const sleeperMat = new THREE.MeshStandardMaterial({ color: 0x4a3528, roughness: 0.8 });
      const sleeperPlacements: Placement[] = [];
      for (let z = -390; z < 30; z += 3.4) sleeperPlacements.push({ x: 6.2, y: -0.01, z });
      worldRoot.add(createInstanced(new THREE.BoxGeometry(3.4, 0.1, 0.28), sleeperMat, sleeperPlacements));
      const decorMat = new THREE.MeshStandardMaterial({ color: world.ground, roughness: 0.9 });
      const accentColor = biome === 1 ? 0x492b9d : biome === 2 ? 0xffffff : biome === 3 ? 0x4b1410 : biome === 4 ? 0x8a7f92 : 0xd46832;
      const accentMat = new THREE.MeshStandardMaterial({ color: accentColor, roughness: 0.7, emissive: biome === 3 ? 0x5c1100 : 0x000000, emissiveIntensity: 0.75 + chapter * 0.08 });
      const neonMat = new THREE.MeshStandardMaterial({ color: biome === 3 ? 0xff6a20 : 0x33efff, emissive: biome === 3 ? 0xff3a00 : 0x17cfe4, emissiveIntensity: 2.6 + chapter * 0.12, metalness: 0.25, roughness: 0.2 });
      for (let i = 0; i < 48; i++) {
        const side = i % 2 ? 1 : -1;
        const prop = new THREE.Group();
        const x = side * (14 + Math.random() * 24);
        const z = -10 - i * 8.5 - Math.random() * 10;
        if (biome === 0) {
          const size = 3 + Math.random() * 5;
          const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(size, 0), i % 3 ? decorMat : accentMat);
          rock.position.y = size * 0.55;
          rock.rotation.set(Math.random(), Math.random(), Math.random());
          prop.add(rock);
          if (i % 6 === 0) {
            const cactusMat = new THREE.MeshStandardMaterial({ color: 0x47783d, roughness: 0.86 });
            const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.48, 5, 8), cactusMat);
            trunk.position.set(-side * 3, 2.5, 1);
            prop.add(trunk);
            for (const armSide of [-1, 1]) {
              const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.26, 2.1, 8), cactusMat);
              arm.position.set(-side * 3 + armSide * 0.7, 2.6, 1);
              arm.rotation.z = armSide * 0.9;
              prop.add(arm);
            }
          }
        } else if (biome === 1) {
          const width = 4 + Math.random() * 6;
          const height = 10 + Math.random() * 28;
          const depth = 5 + Math.random() * 7;
          const building = new THREE.Mesh(new THREE.BoxGeometry(width, height, depth), i % 3 ? decorMat : accentMat);
          building.position.y = height / 2;
          prop.add(building);
          for (let y = 3; y < height - 2; y += 3.5) {
            const strip = new THREE.Mesh(new THREE.BoxGeometry(width * 0.72, 0.16, depth + 0.05), neonMat);
            strip.position.y = y;
            prop.add(strip);
          }
          const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 4 + Math.random() * 4, 8), neonMat);
          antenna.position.y = height + 2;
          prop.add(antenna);
        } else if (biome === 2) {
          const height = 12 + Math.random() * 19;
          const mountain = new THREE.Mesh(new THREE.ConeGeometry(4 + Math.random() * 5, height, 7), decorMat);
          mountain.position.y = height / 2 - 1;
          prop.add(mountain);
          const cap = new THREE.Mesh(new THREE.ConeGeometry(2.1 + Math.random() * 2, height * 0.28, 7), accentMat);
          cap.position.y = height * 0.83;
          prop.add(cap);
          if (i % 4 === 0) {
            const pineMat = new THREE.MeshStandardMaterial({ color: 0x17484a, roughness: 0.86 });
            for (let p = 0; p < 3; p++) {
              const pine = new THREE.Mesh(new THREE.ConeGeometry(1.25 - p * 0.18, 3.2, 8), pineMat);
              pine.position.set(-side * (4 + p * 1.8), 1.6, p * 1.1);
              prop.add(pine);
            }
          }
        } else if (biome === 3) {
          const rock = new THREE.Mesh(new THREE.DodecahedronGeometry(3 + Math.random() * 5, 0), i % 3 ? decorMat : accentMat);
          rock.position.y = 2.5;
          rock.rotation.set(Math.random(), Math.random(), Math.random());
          prop.add(rock);
          if (i % 5 === 0) {
            const lava = new THREE.Mesh(new THREE.CircleGeometry(2.4 + Math.random() * 2, 20), neonMat);
            lava.rotation.x = -Math.PI / 2;
            lava.position.set(-side * 4, 0.03, 2);
            prop.add(lava);
            const stack = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.9, 9, 12), new THREE.MeshStandardMaterial({ color: 0x171316, metalness: 0.62, roughness: 0.48 }));
            stack.position.set(side * 2.5, 4.5, 0);
            prop.add(stack);
          }
        } else {
          const height = 12 + Math.random() * 18;
          const pylon = new THREE.Mesh(new THREE.CylinderGeometry(1.3, 2.1, height, 8), i % 3 ? decorMat : accentMat);
          pylon.position.y = height / 2;
          prop.add(pylon);
          for (const y of [height * 0.42, height * 0.72]) {
            const cross = new THREE.Mesh(new THREE.BoxGeometry(8, 0.42, 0.55), neonMat);
            cross.position.y = y;
            prop.add(cross);
          }
          if (i % 5 === 0) for (let c = 0; c < 4; c++) {
            const cloud = new THREE.Mesh(new THREE.SphereGeometry(2 + Math.random() * 1.3, 12, 8), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.34 }));
            cloud.position.set(-side * (5 + c * 2), 13 + c, c * 1.8);
            prop.add(cloud);
          }
        }
        prop.position.set(x, 0, z);
        prop.traverse((node) => { if (node instanceof THREE.Mesh) { node.castShadow = false; node.receiveShadow = true; } });
        scenery.push(prop);
        worldRoot.add(prop);
      }

      const postMat = new THREE.MeshStandardMaterial({ color: 0xbac3c7, metalness: 0.86, roughness: 0.25 });
      const polePlacements: Placement[] = [];
      const markerPlacements: Placement[] = [];
      for (let z = -390; z < 25; z += 24) for (const x of [-10.8, 10.8]) {
        polePlacements.push({ x, y: 1.3, z });
        markerPlacements.push({ x, y: 2.45, z });
      }
      addScrollBatch(new THREE.CylinderGeometry(0.07, 0.1, 2.6, 8), postMat, polePlacements, 35, 430);
      addScrollBatch(new THREE.BoxGeometry(0.32, 0.55, 0.12), biome === 1 ? neonMat : edgeMat, markerPlacements, 35, 430);

      const particleCount = (biome === 2 ? 220 : biome === 3 ? 160 : 100) + chapter * 18;
      const particlePositions = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount; i++) {
        particlePositions[i * 3] = (Math.random() - 0.5) * 65;
        particlePositions[i * 3 + 1] = 0.5 + Math.random() * 26;
        particlePositions[i * 3 + 2] = 25 - Math.random() * 235;
      }
      const particleGeometry = new THREE.BufferGeometry();
      particleGeometry.setAttribute("position", new THREE.BufferAttribute(particlePositions, 3));
      const particleColors = [0xffcb83, 0x58f5ff, 0xffffff, 0xff6a2a, 0xeaf8ff];
      weatherSystem = new THREE.Points(particleGeometry, new THREE.PointsMaterial({ color: particleColors[biome], size: biome === 2 ? 0.18 : 0.11, transparent: true, opacity: biome === 1 ? 0.72 : 0.6, depthWrite: false, blending: biome === 3 ? THREE.AdditiveBlending : THREE.NormalBlending }));
      weatherSystem.userData.kind = biome;
      worldRoot.add(weatherSystem);

      const sunBall = new THREE.Mesh(new THREE.SphereGeometry(biome === 0 ? 7 : 3.5, 28, 18), new THREE.MeshBasicMaterial({ color: sunColors[biome] }));
      sunBall.position.set(biome === 0 ? -6 + chapter * 3 : 25, biome === 0 ? 18 : 32, -135);
      worldRoot.add(sunBall);
      const halo = new THREE.Mesh(new THREE.SphereGeometry(biome === 0 ? 9.5 : 5, 20, 14), new THREE.MeshBasicMaterial({ color: sunColors[biome], transparent: true, opacity: 0.12, depthWrite: false }));
      halo.position.copy(sunBall.position);
      worldRoot.add(halo);
    }

    function removeObject(obj: Spawned) {
      objectRoot.remove(obj.mesh);
      obj.mesh.traverse(disposeNode);
    }

    function clearObjects() {
      objects.forEach(removeObject);
      objects = [];
    }

    function spawn(kind?: Spawned["kind"], forcedX?: number) {
      let finalKind = kind;
      if (!finalKind) {
        const roll = spawnCount % 30;
        if (roll === 12 || (WORLDS[levelIndex].kind === "train" && roll === 6)) finalKind = "cargoTrain";
        else if (roll === 21) finalKind = "oncomingTrain";
        else if (roll % 9 === 0) finalKind = "power";
        else if (roll % 4 === 0) finalKind = "coin";
        else finalKind = Math.random() > 0.48 ? "barrier" : "rock";
      }
      const lane = forcedX ?? [-6.1, -3, 0, 3, 6.1][Math.floor(Math.random() * 5)];
      let mesh: Object3D;
      let radius = 1.2;
      let radiusZ = 1.4;
      let value: PowerKind | undefined;
      if (finalKind === "barrier") {
        mesh = new THREE.Group();
        const base = new THREE.Mesh(new THREE.BoxGeometry(2.6, 1.05, 0.65), new THREE.MeshStandardMaterial({ color: 0xf4b229, roughness: 0.5 }));
        base.position.y = 0.52;
        base.castShadow = true;
        mesh.add(base);
        for (const x of [-0.8, 0, 0.8]) {
          const stripe = new THREE.Mesh(new THREE.BoxGeometry(0.28, 1.08, 0.68), new THREE.MeshBasicMaterial({ color: 0x181818 }));
          stripe.position.set(x, 0.54, 0);
          stripe.rotation.z = -0.35;
          mesh.add(stripe);
        }
      } else if (finalKind === "rock") {
        mesh = new THREE.Mesh(new THREE.DodecahedronGeometry(1.35, 1), new THREE.MeshStandardMaterial({ color: WORLDS[levelIndex].biome === 2 ? 0xbde8f2 : 0x654132, roughness: 0.95 }));
        mesh.position.y = 1.1;
        mesh.castShadow = true;
        radius = 1.35;
      } else if (finalKind === "oncomingTrain") {
        mesh = trainMesh(false);
        radius = 2.15;
        radiusZ = 5.5;
      } else if (finalKind === "cargoTrain") {
        mesh = trainMesh(true);
        radius = 2.25;
        radiusZ = 23;
      } else if (finalKind === "checkpoint") {
        const mat = new THREE.MeshStandardMaterial({ color: 0x16e7ff, emissive: 0x16b8cc, emissiveIntensity: 1.6, metalness: 0.45 });
        mesh = new THREE.Group();
        const top = new THREE.Mesh(new THREE.BoxGeometry(16, 0.35, 0.35), mat);
        top.position.y = 5.7;
        const left = new THREE.Mesh(new THREE.BoxGeometry(0.35, 5.8, 0.35), mat);
        left.position.set(-7.5, 2.85, 0);
        const right = left.clone();
        right.position.x = 7.5;
        mesh.add(top, left, right);
        radius = 8;
        radiusZ = 0.7;
      } else {
        const isPart = finalKind === "part";
        if (finalKind === "power") value = LEVEL_POWER[levelIndex];
        const color = isPart ? 0xffc13d : finalKind === "coin" ? 0xffc13d : POWER_META[value!].color;
        const geo = isPart ? new THREE.TorusKnotGeometry(0.55, 0.18, 48, 8) : finalKind === "coin" ? new THREE.CylinderGeometry(0.68, 0.68, 0.18, 24) : new THREE.OctahedronGeometry(0.82, 0);
        mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.75, metalness: 0.62, roughness: 0.22 }));
        mesh.rotation.z = Math.PI / 2;
        mesh.position.y = isPart ? 1.35 : 1.2;
        let glowMat = glowMaterials.get(color);
        if (!glowMat) {
          glowMat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.16, depthWrite: false, blending: THREE.AdditiveBlending });
          glowMat.userData.shared = true;
          glowMaterials.set(color, glowMat);
        }
        const glow = new THREE.Mesh(glowGeometry, glowMat);
        glow.userData.shared = true;
        mesh.add(glow);
        radius = 0.9;
      }
      mesh.position.x = finalKind === "cargoTrain" ? 6.15 : lane;
      mesh.position.z = -145 - Math.random() * 22;
      mesh.userData.baseX = mesh.position.x;
      objectRoot.add(mesh);
      objects.push({ mesh, kind: finalKind, x: mesh.position.x, radius, radiusZ, value, spin: Math.random() * 3 });
    }

    function activePower(ability: AbilityKind) {
      return Object.keys(active).find((id) => (active[id] ?? 0) > 0 && POWER_META[id]?.ability === ability);
    }

    function powerStrength(id: PowerKind) {
      const upgrade = powerUpgradesRef.current[id] ?? 0;
      return POWER_META[id].strength * (1 + upgrade * 0.2);
    }

    function triggerPower(kind: PowerKind) {
      audioRef.current?.power();
      const meta = POWER_META[kind];
      const upgrade = powerUpgradesRef.current[kind] ?? 0;
      const strength = powerStrength(kind);
      active[kind] = meta.duration * (1 + upgrade * 0.16);
      if (meta.ability === "boost") { boost = 100; speed = Math.min(275, speed + 58 * strength); }
      if (meta.ability === "emp") {
        gap = Math.min(40, gap + 15 * strength);
        catcher.position.z += 3.4 * strength;
      }
    }

    function hitObstacle() {
      const shield = activePower("shield");
      if (shield) {
        delete active[shield];
        shake = 0.25;
        return;
      }
      speed = Math.max(42, speed * 0.48);
      gap -= 8.5;
      cargo = Math.max(0, cargo - (WORLDS[levelIndex].kind === "cargo" ? 16 : 5));
      shake = 0.55;
      audioRef.current?.impact();
    }

    function missionProgress() {
      return progressText(WORLDS[levelIndex], distance, checkpoints, roofTime, parts, cargo);
    }

    function finishIfReady() {
      const world = WORLDS[levelIndex];
      let done = world.kind === "distance" && distance >= world.target;
      if (world.kind === "checkpoints") done = checkpoints >= world.target;
      if (world.kind === "train") done = roofTime >= world.secondaryTarget && distance >= world.target;
      if (world.kind === "parts") done = parts >= world.target;
      if (world.kind === "cargo") done = distance >= world.target && cargo > 0;
      if (!done || statusRef.current !== "playing") return;
      speed = 0;
      audioRef.current?.complete();
      recordProgress(levelIndex, coins);
      if (levelIndex === WORLDS.length - 1) changeStatus("won");
      else changeStatus("complete");
    }

    function setupLevel(index: number, nextStatus: GameStatus) {
      levelIndex = index;
      levelRef.current = index;
      setLevel(index);
      clearObjects();
      rebuildWorld(index);
      distance = 0;
      speed = 0;
      gap = 28;
      boost = Math.max(boost, 60);
      playerX = 0;
      playerY = 0.02;
      playerVY = 0;
      onTrain = false;
      spawnClock = 0;
      spawnCount = 0;
      checkpoints = 0;
      roofTime = 0;
      parts = 0;
      cargo = 100;
      active = {};
      player.position.set(0, 0.02, 5);
      catcher.visible = true;
      catcher.position.set(-1.8, 0, 10.2);
      officer.visible = false;
      fugitive.visible = false;
      officer.position.set(0, 0, 0);
      fugitive.position.set(0, 0, 0);
      officer.rotation.set(0, 0, 0);
      fugitive.rotation.set(0, 0, 0);
      if (policeDoor) policeDoor.rotation.y = 0;
      if (driverLeftCuff) driverLeftCuff.visible = false;
      if (driverRightCuff) driverRightCuff.visible = false;
      cuffChain.visible = false;
      [driverLeftArm, driverRightArm, driverLeftLeg, driverRightLeg, officerLeftArm, officerRightArm, officerLeftLeg, officerRightLeg].forEach((limb) => limb?.rotation.set(0, 0, 0));
      arrestTime = 0;
      arrestPhase = -1;
      setHud({ ...initialHud, coins, boost, gap, progress: progressText(WORLDS[index], 0, 0, 0, 0, 100) });
      changeStatus(nextStatus);
    }

    function applyCustomization(vehicleId: string, skinId: string, outfitId: string) {
      const vehicle = VEHICLES.find((entry) => entry.id === vehicleId) ?? VEHICLES[0];
      const skin = SKINS.find((entry) => entry.id === skinId) ?? SKINS[0];
      const outfit = OUTFITS.find((entry) => entry.id === outfitId) ?? OUTFITS[0];
      player.scale.set(0.78 * vehicle.scale[0], 0.78 * vehicle.scale[1], 0.78 * vehicle.scale[2]);
      player.userData.speedBonus = vehicle.speedBonus;
      player.traverse((node) => {
        if (node instanceof THREE.Mesh && !Array.isArray(node.material) && node.material.name === "car-paint" && "color" in node.material) node.material.color.setHex(skin.color);
      });
      fugitive.traverse((node) => {
        if (node instanceof THREE.Mesh && !Array.isArray(node.material) && node.material.name === "driver-outfit" && "color" in node.material) node.material.color.setHex(outfit.color);
      });
    }

    apiRef.current = {
      startLevel(index) { setupLevel(index, "playing"); speed = 72; },
      showBriefing(index) { setupLevel(index, "briefing"); },
      showShop() {
        speed = 0;
        catcher.visible = false;
        officer.visible = false;
        fugitive.visible = true;
        if (driverLeftCuff) driverLeftCuff.visible = false;
        if (driverRightCuff) driverRightCuff.visible = false;
        cuffChain.visible = false;
        driverLeftArm?.rotation.set(0, 0, 0);
        driverRightArm?.rotation.set(0, 0, 0);
        fugitive.position.set(2.6, 0.02, 5.2);
        fugitive.rotation.y = -0.35;
        player.position.set(-0.8, 0.02, 5);
        applyCustomization(equipmentRef.current.vehicle, equipmentRef.current.skin, equipmentRef.current.outfit);
        changeStatus("shop");
      },
      applyCustomization,
      restart() { setupLevel(levelIndex, "playing"); speed = 72; },
      next() { setupLevel(Math.min(WORLDS.length - 1, levelIndex + 1), "briefing"); },
      resetCampaign() { coins = 0; boost = 64; catcher.visible = true; fugitive.visible = false; setupLevel(0, "menu"); applyCustomization(equipmentRef.current.vehicle, equipmentRef.current.skin, equipmentRef.current.outfit); },
      pause() { if (statusRef.current === "playing") { audioRef.current?.pause(); changeStatus("paused"); } },
      resume() { if (statusRef.current === "paused") { audioRef.current?.resume(); changeStatus("playing"); } },
    };
    rebuildWorld(0);
    applyCustomization(equipmentRef.current.vehicle, equipmentRef.current.skin, equipmentRef.current.outfit);
    activateEngine();

    function onKeyDown(event: KeyboardEvent) {
      const key = event.key.toLowerCase();
      keysRef.current[key] = true;
      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(key)) event.preventDefault();
      if ((key === " " || key === "spacebar") && statusRef.current === "playing" && (playerY <= (onTrain ? 2.48 : 0.08))) { playerVY = 7.2; audioRef.current?.jump(); }
      if (key === "enter" && statusRef.current === "menu") apiRef.current?.showBriefing(0);
      if (key === "escape") {
        if (statusRef.current === "playing") apiRef.current?.pause();
        else if (statusRef.current === "paused") apiRef.current?.resume();
      }
    }
    function onKeyUp(event: KeyboardEvent) { keysRef.current[event.key.toLowerCase()] = false; }
    window.addEventListener("keydown", onKeyDown, { passive: false });
    window.addEventListener("keyup", onKeyUp);

    function onResize() {
      if (!host) return;
      camera.aspect = host.clientWidth / host.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(host.clientWidth, host.clientHeight);
    }
    window.addEventListener("resize", onResize);

    function animate(now: number) {
      const currentStatus = statusRef.current;
      const idle = currentStatus !== "playing" && currentStatus !== "arresting" && currentStatus !== "caught" && currentStatus !== "shop";
      // 60-fps-Deckel (ProMotion/120 Hz), im Leerlauf 30 fps.
      if (now - last < (idle ? 33 : 14)) {
        raf = requestAnimationFrame(animate);
        return;
      }
      const frameMs = now - last;
      if (!idle && frameMs < 250) {
        avgFrameMs += (frameMs - avgFrameMs) * 0.05;
        adaptCooldown -= frameMs;
        if (adaptCooldown <= 0 && avgFrameMs > 21 && pixelRatio > 0.75) {
          pixelRatio = Math.max(0.75, pixelRatio - 0.125);
          renderer.setPixelRatio(pixelRatio);
          renderer.setSize(host.clientWidth, host.clientHeight);
          adaptCooldown = 2500;
          avgFrameMs = 16.7;
        }
      }
      const dt = Math.min(0.035, (now - last) / 1000);
      last = now;
      elapsed += dt;
      const playing = statusRef.current === "playing";
      const shopping = statusRef.current === "shop";
      const arresting = statusRef.current === "arresting";
      const caught = statusRef.current === "caught";
      const input = keysRef.current;
      let boostVisual = false;
      if (playing) {
        const accelerating = input.w || input.arrowup;
        const braking = input.s || input.arrowdown;
        const usingBoost = (input.shift || input.shiftleft || input.shiftright) && boost > 0;
        const boostPowerId = activePower("boost");
        const boostPowerStrength = boostPowerId ? powerStrength(boostPowerId) : 0;
        boostVisual = usingBoost;
        audioRef.current?.updateEngine(speed, usingBoost);
        const vehicleBonus = Number(player.userData.speedBonus ?? 0);
        const maxSpeed = (usingBoost ? 245 : 178) + vehicleBonus + boostPowerStrength * 12;
        if (accelerating) speed += (74 + boostPowerStrength * 9) * dt;
        else speed -= 13 * dt;
        if (braking) speed -= 95 * dt;
        if (usingBoost) {
          speed += 135 * dt;
          boost = Math.max(0, boost - 25 * dt);
        } else boost = Math.min(100, boost + 3.4 * dt);
        speed = THREE.MathUtils.clamp(speed, 38, maxSpeed);
        const steering = (input.a || input.arrowleft ? -1 : 0) + (input.d || input.arrowright ? 1 : 0);
        playerX += steering * (5.2 + speed * 0.012) * dt;
        playerX = THREE.MathUtils.clamp(playerX, -8.4, 8.4);
        player.rotation.z = THREE.MathUtils.lerp(player.rotation.z, -steering * 0.13, 0.12);
        player.rotation.y = THREE.MathUtils.lerp(player.rotation.y, -steering * 0.08, 0.1);

        const cargoTrain = objects.find((o) => o.kind === "cargoTrain" && Math.abs(o.mesh.position.z - player.position.z) < o.radiusZ && Math.abs(playerX - o.x) < 2.15);
        const roofBase = 2.62;
        if (cargoTrain && playerY > 1.25 && playerVY <= 0) {
          onTrain = true;
          playerY = roofBase;
          playerVY = 0;
        }
        if (onTrain && (!cargoTrain || Math.abs(playerX - cargoTrain.x) > 2.3)) onTrain = false;
        const baseY = onTrain ? roofBase : 0.02;
        if (playerY > baseY || playerVY > 0) {
          playerVY -= 15.5 * dt;
          playerY += playerVY * dt;
          if (playerY <= baseY) { playerY = baseY; playerVY = 0; }
        }
        player.position.x = THREE.MathUtils.lerp(player.position.x, playerX, 0.24);
        player.position.y = playerY + Math.sin(elapsed * Math.max(5, speed) * 0.055) * (onTrain ? 0.012 : 0.025);
        boostFlames.forEach((flame, flameIndex) => {
          flame.visible = usingBoost;
          const pulse = 0.72 + Math.sin(elapsed * 34 + flameIndex) * 0.22;
          flame.scale.set(pulse, 0.78 + Math.random() * 0.5, pulse);
        });
        if (onTrain) roofTime += dt;

        const slowPowerId = activePower("slow");
        const slowFactor = slowPowerId ? Math.max(0.24, 0.58 - powerStrength(slowPowerId) * 0.12) : 1;
        const scroll = speed * 0.17 * dt * slowFactor;
        distance += speed * 0.20 * dt;
        scrollBatches.forEach((batch) => scrollBatch(batch, scroll));
        scenery.forEach((prop) => {
          prop.position.z += scroll;
          if (prop.position.z > 35) prop.position.z -= 430;
        });
        if (weatherSystem) {
          const position = weatherSystem.geometry.getAttribute("position") as import("three").BufferAttribute;
          const kind = weatherSystem.userData.kind as number;
          for (let i = 0; i < position.count; i++) {
            let x = position.getX(i);
            let y = position.getY(i);
            let z = position.getZ(i) + scroll * (kind === 1 ? 1.2 : 0.42);
            if (kind === 2) { y -= dt * (1.4 + (i % 5) * 0.18); x += Math.sin(elapsed + i) * dt * 0.18; }
            if (kind === 3) y += dt * (1.2 + (i % 4) * 0.28);
            if (kind === 1) y -= dt * 8;
            if (y < 0.2) y = 20 + Math.random() * 8;
            if (y > 28) y = 0.4;
            if (z > 35) z -= 235;
            position.setXYZ(i, x, y, z);
          }
          position.needsUpdate = true;
        }
        spawnClock -= dt;
        if (spawnClock <= 0) {
          spawnCount++;
          const missionWorld = WORLDS[levelIndex];
          if (missionWorld.kind === "checkpoints" && spawnCount % 5 === 0 && checkpoints < missionWorld.target) spawn("checkpoint", 0);
          else if (missionWorld.kind === "parts" && spawnCount % 2 === 0 && parts < missionWorld.target) spawn("part");
          else spawn();
          if (spawnCount % 4 === 0) {
            for (let i = 0; i < 4; i++) {
              spawn("coin", -5 + i * 2.6);
              objects[objects.length - 1].mesh.position.z -= i * 4;
            }
          }
          spawnClock = THREE.MathUtils.lerp(1.1, 0.48, Math.min(1, distance / 500));
        }

        for (const obj of objects) {
          const extra = obj.kind === "oncomingTrain" ? 16 * dt : obj.kind === "cargoTrain" ? -scroll * 0.34 : 0;
          obj.mesh.position.z += scroll + extra;
          if (obj.kind === "rock") obj.mesh.rotation.x += dt * 1.8;
          if (["coin", "part", "power"].includes(obj.kind)) {
            obj.mesh.rotation.y += dt * 3;
            obj.mesh.position.y += Math.sin(elapsed * 4 + (obj.spin ?? 0)) * 0.004;
          }
          if (obj.kind === "cargoTrain") obj.mesh.position.x = 6.15 + Math.sin(elapsed * 0.6) * 0.08;
          if (!obj.processed && Math.abs(obj.mesh.position.z - player.position.z) < obj.radiusZ) {
            const dx = Math.abs(player.position.x - obj.mesh.position.x);
            if (obj.kind === "checkpoint") {
              obj.processed = true;
              checkpoints++;
            } else if ((obj.kind === "coin" || obj.kind === "part" || obj.kind === "power") && (dx < 1.45 || (activePower("magnet") && dx < 7 + powerStrength(activePower("magnet")!) * 2.4))) {
              obj.processed = true;
              obj.mesh.visible = false;
              if (obj.kind === "coin") { coins++; audioRef.current?.coin(); }
              if (obj.kind === "part") { parts++; coins += 2; }
              if (obj.kind === "power" && obj.value) triggerPower(obj.value);
            } else if (["barrier", "rock", "oncomingTrain"].includes(obj.kind) && dx < obj.radius && playerY < (obj.kind === "oncomingTrain" ? 2.9 : 1.45)) {
              obj.processed = true;
              hitObstacle();
            }
          }
          if (activePower("magnet") && (obj.kind === "coin" || obj.kind === "part") && obj.mesh.position.z > -25) {
            obj.mesh.position.x = THREE.MathUtils.lerp(obj.mesh.position.x, player.position.x, dt * 4.5);
          }
        }
        objects = objects.filter((obj) => {
          if (obj.mesh.position.z > 45) { removeObject(obj); return false; }
          return true;
        });

        Object.keys(active).forEach((key) => {
          const kind = key as PowerKind;
          active[kind] = Math.max(0, (active[kind] ?? 0) - dt);
          if ((active[kind] ?? 0) === 0) delete active[kind];
        });
        gap += ((speed - 118) * 0.007 - 0.32) * dt;
        if (usingBoost) gap += 1.5 * dt;
        gap = THREE.MathUtils.clamp(gap, 0, 40);
        catcher.position.z = THREE.MathUtils.lerp(catcher.position.z, 8.1 + gap * 0.105, 0.045);
        catcher.position.x = THREE.MathUtils.lerp(catcher.position.x, player.position.x - 1.7 + Math.sin(elapsed * 0.8) * 0.5, 0.02);
        if (WORLDS[levelIndex].kind === "cargo") cargo = Math.max(0, cargo - (gap < 10 ? 1.8 : 0.18) * dt);
        if (gap <= 0 || (WORLDS[levelIndex].kind === "cargo" && cargo <= 0)) {
          arrestTime = 0;
          arrestPhase = 0;
          setArrestCaption("CATCHER CAR HAT DICH EINGEHOLT");
          audioRef.current?.caught();
          changeStatus("arresting");
          speed = 0;
        }
        finishIfReady();
      } else if (arresting) {
        arrestTime += dt;
        audioRef.current?.updateEngine(0, false);
        catcher.position.x = THREE.MathUtils.lerp(catcher.position.x, player.position.x - 2.45, 0.065);
        catcher.position.z = THREE.MathUtils.lerp(catcher.position.z, 6.25, 0.065);
        if (policeDoor) policeDoor.rotation.y = THREE.MathUtils.lerp(policeDoor.rotation.y, arrestTime > 0.65 ? -1.2 : 0, 0.075);

        const nextPhase = arrestTime >= 6.25 ? 5 : arrestTime >= 5.15 ? 4 : arrestTime >= 3.35 ? 3 : arrestTime >= 2.15 ? 2 : arrestTime >= 0.75 ? 1 : 0;
        if (nextPhase !== arrestPhase) {
          arrestPhase = nextPhase;
          if (nextPhase === 1) setArrestCaption("POLIZIST STEIGT AUS");
          if (nextPhase === 2) setArrestCaption("FLUCHTFAHRER STEIGT AUS");
          if (nextPhase === 3) setArrestCaption("HÄNDE HINTER DEN RÜCKEN");
          if (nextPhase === 4) { setArrestCaption("HANDSCHELLEN ANGELEGT"); audioRef.current?.handcuffs(); }
          if (nextPhase === 5) setArrestCaption("FAHRER WIRD ABGEFÜHRT");
        }

        const approach = THREE.MathUtils.smoothstep(arrestTime, 0.75, 3.35);
        const driverExit = THREE.MathUtils.smoothstep(arrestTime, 2.15, 3.15);
        const restraint = THREE.MathUtils.smoothstep(arrestTime, 3.35, 5.12);
        const turnToCar = THREE.MathUtils.smoothstep(arrestTime, 5.7, 6.35);
        const escort = THREE.MathUtils.smoothstep(arrestTime, 6.2, 8.45);
        const driverStandX = player.position.x + 1.15;
        const driverStandZ = 5.42;
        const gait = Math.sin(arrestTime * 9.2);

        if (arrestTime > 0.72) {
          officer.visible = true;
          const contactX = THREE.MathUtils.lerp(driverStandX - 0.58, driverStandX + 0.5, turnToCar);
          const contactZ = THREE.MathUtils.lerp(driverStandZ + 0.12, driverStandZ + 0.32, turnToCar);
          const preEscortX = THREE.MathUtils.lerp(catcher.position.x + 1.15, contactX, approach);
          const preEscortZ = THREE.MathUtils.lerp(catcher.position.z + 0.38, contactZ, approach);
          officer.position.set(
            THREE.MathUtils.lerp(preEscortX, catcher.position.x + 1.82, escort),
            0.02,
            THREE.MathUtils.lerp(preEscortZ, 5.95, escort),
          );
          officer.rotation.y = THREE.MathUtils.lerp(-Math.PI / 2, Math.PI / 2, turnToCar);
          const walkAmount = Math.max(approach * (1 - restraint), escort);
          const walkSwing = gait * 0.58 * walkAmount;
          const reach = restraint * (1 - escort);
          if (officerLeftArm) {
            officerLeftArm.rotation.x = THREE.MathUtils.lerp(walkSwing, 0.92, reach);
            officerLeftArm.rotation.z = THREE.MathUtils.lerp(0, 0.18, reach);
          }
          if (officerRightArm) {
            const guidedArm = THREE.MathUtils.lerp(1.08, 0.86, escort);
            officerRightArm.rotation.x = THREE.MathUtils.lerp(-walkSwing, guidedArm, Math.max(reach, escort));
            officerRightArm.rotation.z = THREE.MathUtils.lerp(0, -0.16, Math.max(reach, escort));
          }
          if (officerLeftLeg) officerLeftLeg.rotation.x = -walkSwing;
          if (officerRightLeg) officerRightLeg.rotation.x = walkSwing;
        }

        if (arrestTime > 2.1) {
          fugitive.visible = true;
          fugitive.position.set(
            THREE.MathUtils.lerp(THREE.MathUtils.lerp(player.position.x + 0.64, driverStandX, driverExit), catcher.position.x + 1.35, escort),
            0.02,
            THREE.MathUtils.lerp(THREE.MathUtils.lerp(5.12, driverStandZ, driverExit), 5.92, escort),
          );
          fugitive.rotation.y = THREE.MathUtils.lerp(-Math.PI / 2, Math.PI / 2, turnToCar);
          if (driverLeftArm) {
            driverLeftArm.rotation.x = -1.12 * restraint;
            driverLeftArm.rotation.z = 0.42 * restraint;
          }
          if (driverRightArm) {
            driverRightArm.rotation.x = -1.12 * restraint;
            driverRightArm.rotation.z = -0.42 * restraint;
          }
          const driverWalk = gait * 0.44 * Math.max(driverExit * (1 - restraint), escort);
          if (driverLeftLeg) driverLeftLeg.rotation.x = -driverWalk;
          if (driverRightLeg) driverRightLeg.rotation.x = driverWalk;

          const cuffsClosed = arrestTime >= 5.12;
          if (driverLeftCuff) driverLeftCuff.visible = cuffsClosed;
          if (driverRightCuff) driverRightCuff.visible = cuffsClosed;
          cuffChain.visible = cuffsClosed && !!driverLeftCuff && !!driverRightCuff;
          if (cuffChain.visible && driverLeftCuff && driverRightCuff) {
            driverLeftCuff.getWorldPosition(cuffLeftWorld);
            driverRightCuff.getWorldPosition(cuffRightWorld);
            cuffMidWorld.copy(cuffLeftWorld).lerp(cuffRightWorld, 0.5);
            cuffDirection.subVectors(cuffRightWorld, cuffLeftWorld);
            const cuffDistance = Math.max(0.08, cuffDirection.length());
            cuffChain.position.copy(cuffMidWorld);
            cuffChain.scale.set(1, cuffDistance / 0.22, 1);
            cuffChain.quaternion.setFromUnitVectors(cuffYAxis, cuffDirection.normalize());
          }
        }

        const cuffCloseUp = THREE.MathUtils.smoothstep(arrestTime, 4.2, 4.9) * (1 - THREE.MathUtils.smoothstep(arrestTime, 5.9, 6.65));
        const focusX = cuffChain.visible ? cuffMidWorld.x : driverStandX;
        const focusY = cuffChain.visible ? cuffMidWorld.y : 1.15;
        const focusZ = cuffChain.visible ? cuffMidWorld.z : driverStandZ;
        const cameraX = THREE.MathUtils.lerp(player.position.x + 7.2, focusX + 4.15, cuffCloseUp);
        const cameraY = THREE.MathUtils.lerp(3.35, focusY + 1.45, cuffCloseUp);
        const cameraZ = THREE.MathUtils.lerp(9.15, focusZ + 2.55, cuffCloseUp);
        camera.position.x = THREE.MathUtils.lerp(camera.position.x, cameraX, 0.05);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, cameraY, 0.05);
        camera.position.z = THREE.MathUtils.lerp(camera.position.z, cameraZ, 0.05);
        camera.fov = THREE.MathUtils.lerp(camera.fov, THREE.MathUtils.lerp(48, 38, cuffCloseUp), 0.05);
        camera.updateProjectionMatrix();
        camera.lookAt(
          THREE.MathUtils.lerp(player.position.x - 0.2, focusX, cuffCloseUp),
          THREE.MathUtils.lerp(1.12, focusY, cuffCloseUp),
          THREE.MathUtils.lerp(5.72, focusZ, cuffCloseUp),
        );
        if (arrestTime >= 8.75) changeStatus("caught");
      } else if (caught) {
        catcher.position.x = THREE.MathUtils.lerp(catcher.position.x, player.position.x - 2.2, 0.04);
        catcher.position.z = THREE.MathUtils.lerp(catcher.position.z, 5.5, 0.05);
        camera.position.x = THREE.MathUtils.lerp(camera.position.x, 5.8, 0.025);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, 4.2, 0.025);
        camera.lookAt(player.position.x, 0.8, 5);
      } else if (shopping) {
        player.position.x = THREE.MathUtils.lerp(player.position.x, -0.8, 0.08);
        player.position.z = THREE.MathUtils.lerp(player.position.z, 5, 0.08);
        player.rotation.y += dt * 0.38;
        fugitive.visible = true;
        fugitive.position.set(2.6, 0.02, 5.2);
        fugitive.rotation.y = -0.35 + Math.sin(elapsed * 0.7) * 0.05;
        camera.position.x = THREE.MathUtils.lerp(camera.position.x, 7.2, 0.05);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, 3.8, 0.05);
        camera.position.z = THREE.MathUtils.lerp(camera.position.z, 11.5, 0.05);
        camera.fov = THREE.MathUtils.lerp(camera.fov, 46, 0.05);
        camera.updateProjectionMatrix();
        camera.lookAt(0.2, 1.0, 5);
      } else {
        player.rotation.y = Math.sin(elapsed * 0.55) * 0.02;
      }

      const flash = Math.sin(elapsed * 15) > 0;
      const redLamp = catcher.getObjectByName("police-red");
      const blueLamp = catcher.getObjectByName("police-blue");
      if (redLamp) redLamp.visible = flash;
      if (blueLamp) blueLamp.visible = !flash;
      if (!caught && !arresting && !shopping) {
        camera.position.x = THREE.MathUtils.lerp(camera.position.x, player.position.x * 0.22, 0.04);
        camera.position.y = THREE.MathUtils.lerp(camera.position.y, 6.4 + playerY * 0.28, 0.04);
        camera.position.z = THREE.MathUtils.lerp(camera.position.z, 15.2, 0.04);
        const targetFov = boostVisual ? 68 : 58 + Math.min(5, speed / 45);
        camera.fov = THREE.MathUtils.lerp(camera.fov, targetFov, 0.065);
        camera.updateProjectionMatrix();
        camera.lookAt(player.position.x * 0.18, 1.15 + playerY * 0.18, -12);
      }
      if (shake > 0) {
        camera.position.x += (Math.random() - 0.5) * shake;
        camera.position.y += (Math.random() - 0.5) * shake * 0.4;
        shake = Math.max(0, shake - dt * 1.6);
      }
      hudClock -= dt;
      if (hudClock <= 0) {
        setHud({ distance, speed, coins, boost, gap, progress: missionProgress(), timer: Math.max(0, 90 - distance / 15), cargo, active: { ...active } });
        hudClock = 0.09;
      }
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    }
    raf = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      renderer.dispose();
      clearObjects();
      clearGroup(worldRoot);
      glowGeometry.dispose();
      glowMaterials.forEach((m) => m.dispose());
      if (host.contains(renderer.domElement)) host.removeChild(renderer.domElement);
      apiRef.current = null;
    };
    };
    void boot()
      .then((result) => {
        if (disposed) result?.();
        else cleanup = result;
      })
      .catch((error: unknown) => {
        console.error("Catcher Car engine failed to start", error);
        if (!disposed) setEngineFailed(true);
      });
    return () => {
      disposed = true;
      cleanup?.();
      audioRef.current?.stop();
      audioRef.current = null;
    };
  }, [changeStatus, recordProgress]);

  const openCampaign = () => {
    const startAt = unlockedLevel;
    if (apiRef.current) {
      apiRef.current.showBriefing(startAt);
      return;
    }
    pendingActionRef.current = { type: "showBriefing", level: startAt };
    levelRef.current = startAt;
    setLevel(startAt);
    changeStatus("briefing");
  };

  const openShop = () => {
    audioRef.current?.pause();
    setShopMessage("Wähle deine Ausrüstung");
    if (apiRef.current) apiRef.current.showShop();
    else changeStatus("shop");
  };

  const closeShop = () => {
    apiRef.current?.resetCampaign();
    changeStatus("menu");
  };

  const spendCoins = (price: number) => {
    if (wallet < price) { setShopMessage(`Dir fehlen ${price - wallet} Münzen`); return false; }
    const nextWallet = wallet - price;
    setWallet(nextWallet);
    saveLocal("rail-rush-wallet", nextWallet);
    return true;
  };

  const chooseVehicle = (id: string, price: number) => {
    if (!ownedVehicles.includes(id)) {
      if (!spendCoins(price)) return;
      const next = [...ownedVehicles, id]; setOwnedVehicles(next); saveLocal("rail-rush-owned-vehicles", next);
      setShopMessage("Neues 3D-Fahrzeug gekauft!");
    } else setShopMessage("Fahrzeug ausgerüstet");
    setSelectedVehicle(id); saveLocal("rail-rush-selected-vehicle", id);
  };

  const chooseSkin = (id: string, price: number) => {
    if (!ownedSkins.includes(id)) {
      if (!spendCoins(price)) return;
      const next = [...ownedSkins, id]; setOwnedSkins(next); saveLocal("rail-rush-owned-skins", next);
      setShopMessage("Neuer Fahrzeug-Skin gekauft!");
    } else setShopMessage("Skin ausgerüstet");
    setSelectedSkin(id); saveLocal("rail-rush-selected-skin", id);
  };

  const chooseOutfit = (id: string, price: number) => {
    if (!ownedOutfits.includes(id)) {
      if (!spendCoins(price)) return;
      const next = [...ownedOutfits, id]; setOwnedOutfits(next); saveLocal("rail-rush-owned-outfits", next);
      setShopMessage("Neues Fahrer-Outfit gekauft!");
    } else setShopMessage("Outfit ausgerüstet");
    setSelectedOutfit(id); saveLocal("rail-rush-selected-outfit", id);
  };

  const upgradePower = (id: PowerKind, index: number) => {
    const currentLevel = powerUpgrades[id] ?? 0;
    if (currentLevel >= 5) { setShopMessage("Dieses Power-up ist bereits maximal verbessert"); return; }
    const price = 140 + currentLevel * 160 + Math.floor(index / 5) * 35;
    if (!spendCoins(price)) return;
    const next = { ...powerUpgrades, [id]: currentLevel + 1 };
    setPowerUpgrades(next); saveLocal("rail-rush-power-upgrades", next);
    setShopMessage(`${POWER_META[id].label} erreicht Stufe ${currentLevel + 1}`);
  };

  const startMission = () => {
    void startMusic(level);
    if (apiRef.current) {
      apiRef.current.startLevel(level);
      return;
    }
    pendingActionRef.current = { type: "startLevel", level };
  };

  const restartMission = () => {
    void startMusic(level);
    apiRef.current?.restart();
  };

  const returnToMenu = () => {
    audioRef.current?.stop();
    audioRef.current = null;
    setAudioStatus("ready");
    apiRef.current?.resetCampaign();
  };

  const skipArrest = () => {
    setArrestCaption("HANDSCHELLEN ANGELEGT");
    audioRef.current?.handcuffs();
    changeStatus("caught");
  };

  const selectMission = (index: number) => {
    if (index > unlockedLevel) return;
    if (apiRef.current) {
      apiRef.current.showBriefing(index);
      return;
    }
    pendingActionRef.current = { type: "showBriefing", level: index };
    levelRef.current = index;
    setLevel(index);
    changeStatus("briefing");
  };

  const togglePause = () => {
    if (status === "playing") apiRef.current?.pause();
    else if (status === "paused") apiRef.current?.resume();
  };

  const press = (key: string, down: boolean) => {
    keysRef.current[key] = down;
    if (key === " " && down) window.dispatchEvent(new KeyboardEvent("keydown", { key: " " }));
  };

  const current = WORLDS[level];
  const showMenu = status === "menu";
  const showShop = status === "shop";

  return (
    <main className={`game-shell world-${level} status-${status}`}>
      <div className="game-canvas" ref={mountRef} aria-label="Interaktive 3D-Rennstrecke" />
      {showMenu && <div className="menu-art" aria-hidden="true" />}
      <div className="vignette" aria-hidden="true" />
      <header className="topbar">
        <div className="mini-brand"><span>CC</span><strong>RAIL RUSH</strong><em>FULL 3D</em></div>
        {(showMenu || showShop) && <div className="career-pill"><small>SHOP-GUTHABEN</small><strong>🪙 {wallet}</strong><span>{unlockedLevel + 1}/30 · BEST {bestCoins}</span></div>}
        <div className="world-pill"><span>{current.icon}</span><div><small>{current.subtitle}</small><strong>{current.name}</strong></div></div>
        {(status === "playing" || status === "paused") && <button className="pause-button" onClick={togglePause} aria-label={status === "playing" ? "Spiel pausieren" : "Spiel fortsetzen"}>{status === "playing" ? "Ⅱ" : "▶"}</button>}
        {(status === "playing" || status === "paused") && <button className={`music-status ${audioStatus}`} onClick={toggleSound} aria-label={audioStatus === "playing" ? `Musik läuft: ${MUSIC_TRACKS[level]}` : soundOn ? "Musik erneut aktivieren" : "Musik einschalten"}><span>♫</span><div><small>{audioStatus === "playing" ? "MUSIK LÄUFT" : audioStatus === "blocked" ? "MUSIK ANTIPPEN" : audioStatus === "muted" ? "TON AUS" : "MUSIK BEREIT"}</small><strong>{MUSIC_TRACKS[level]}</strong></div><i /><i /><i /></button>}
        <button className="sound-button" onClick={toggleSound} aria-label={soundOn ? "Ton ausschalten" : "Ton einschalten"}>{soundOn ? "🔊" : "🔇"}</button>
      </header>

      {status === "playing" && (
        <>
          <section className="hud" aria-label="Spielwerte">
            <div className="hud-card"><span>🛣️</span><small>DISTANZ</small><strong>{Math.floor(hud.distance)} m</strong></div>
            <div className="hud-card"><span>◴</span><small>TEMPO</small><strong>{Math.floor(hud.speed)} <em>km/h</em></strong></div>
            <div className="hud-card"><span>🪙</span><small>MÜNZEN</small><strong>{hud.coins}</strong></div>
            <div className="hud-card boost-card"><span>⚡</span><small>BOOST</small><div className="boost-track"><i style={{ width: `${hud.boost}%` }} /></div></div>
          </section>
          <section className="mission-hud">
            <div><small>{current.mission}</small><strong>{hud.progress}</strong></div>
            <div className="gap-wrap"><span>CATCHER CAR</span><div className="gap-track"><i style={{ width: `${Math.max(2, (hud.gap / 40) * 100)}%` }} /></div><b>{hud.gap.toFixed(0)} m</b></div>
          </section>
          <div className="active-powers" aria-label="Aktive Power-ups">
            {(Object.keys(hud.active) as PowerKind[]).map((kind) => <div key={kind}><span>{POWER_META[kind].icon}</span>{POWER_META[kind].label}<b>{Math.ceil(hud.active[kind] ?? 0)}s</b></div>)}
          </div>
          <div className="controls-strip"><span><kbd>WASD</kbd> LENKEN</span><span><kbd>LEER</kbd> SPRINGEN</span><span><kbd>SHIFT</kbd> BOOST</span></div>
          <div className="mobile-controls">
            <button onPointerDown={() => press("a", true)} onPointerUp={() => press("a", false)} onPointerLeave={() => press("a", false)}>◀</button>
            <button onPointerDown={() => press("d", true)} onPointerUp={() => press("d", false)} onPointerLeave={() => press("d", false)}>▶</button>
            <button className="jump" onPointerDown={() => press(" ", true)} onPointerUp={() => press(" ", false)}>SPRUNG</button>
            <button className="boost" onPointerDown={() => press("shift", true)} onPointerUp={() => press("shift", false)} onPointerLeave={() => press("shift", false)}>BOOST</button>
          </div>
        </>
      )}

      {showMenu && (
        <section className="start-screen">
          <div className="title-card"><span className="edition-badge">30-LEVEL-VOLLVERSION · ULTRA 3D</span><span className="eyebrow">SECHS KAPITEL · DREISSIG JAGDEN</span><h1>CATCHER CAR —<br /><em>RAIL RUSH</em></h1><p>Rase durch 30 unterschiedliche 3D-Level, entdecke 30 Musiktracks und sammle in jeder Mission ein eigenes Spezial-Power-up.</p></div>
          <div className="menu-actions"><button className="primary-button" onClick={openCampaign}>{unlockedLevel > 0 ? `LEVEL ${unlockedLevel + 1} WEITER` : "JAGD STARTEN"} <span>➜</span></button><button className="shop-button" onClick={openShop}><span>🛒</span> 3D-SHOP <b>🪙 {wallet}</b></button></div>
          <div className="campaign-route" aria-label="Missionsauswahl">{WORLDS.map((world, i) => <button key={world.name} onClick={() => selectMission(i)} disabled={i > unlockedLevel} className={i === unlockedLevel ? "active" : i < unlockedLevel ? "unlocked" : "locked"} aria-label={`${world.name}${i > unlockedLevel ? " gesperrt" : " auswählen"}`}><b>{i > unlockedLevel ? "🔒" : i + 1}</b><span>{world.icon}<small>{world.name}</small></span><em>{i < unlockedLevel ? "✓" : i === unlockedLevel ? "START" : "GESPERRT"}</em></button>)}</div>
          <div className="start-controls"><kbd>W A S D</kbd><span>FREI LENKEN</span><kbd>LEERTASTE</kbd><span>SPRINGEN</span><kbd>SHIFT</kbd><span>BOOST</span><kbd>ESC</kbd><span>PAUSE</span></div>
        </section>
      )}

      {showShop && (
        <section className="shop-screen" aria-label="3D-Shop">
          <div className="shop-head"><div><small>GARAGE & POWER-LABOR</small><h2>3D-SHOP</h2><p>{shopMessage}</p></div><div className="shop-wallet">🪙 <strong>{wallet}</strong></div><button onClick={closeShop} aria-label="Shop schließen">✕</button></div>
          <nav className="shop-tabs" aria-label="Shop-Abteilungen">
            <button className={shopTab === "vehicles" ? "active" : ""} onClick={() => setShopTab("vehicles")}>🏎️ FAHRZEUGE</button>
            <button className={shopTab === "skins" ? "active" : ""} onClick={() => setShopTab("skins")}>🎨 SKINS</button>
            <button className={shopTab === "outfits" ? "active" : ""} onClick={() => setShopTab("outfits")}>🧥 OUTFITS</button>
            <button className={shopTab === "powerups" ? "active" : ""} onClick={() => setShopTab("powerups")}>⚡ POWER-UPS</button>
          </nav>
          <div className="shop-catalog">
            {shopTab === "vehicles" && VEHICLES.map((item) => { const owned = ownedVehicles.includes(item.id); const selected = selectedVehicle === item.id; return <article key={item.id} className={`shop-card ${selected ? "selected" : ""}`}><div className="shop-item-icon">{item.icon}</div><small>3D-FAHRZEUG</small><h3>{item.name}</h3><p>Tempo-Bonus +{item.speedBonus} km/h</p><button onClick={() => chooseVehicle(item.id, item.price)}>{selected ? "AUSGERÜSTET" : owned ? "AUSRÜSTEN" : `🪙 ${item.price}`}</button></article>; })}
            {shopTab === "skins" && SKINS.map((item) => { const owned = ownedSkins.includes(item.id); const selected = selectedSkin === item.id; return <article key={item.id} className={`shop-card ${selected ? "selected" : ""}`}><div className="skin-orb" style={{ background: item.accent, boxShadow: `0 0 28px ${item.accent}` }} /><small>3D-LACKIERUNG</small><h3>{item.name}</h3><p>Direkt am Fahrzeug sichtbar</p><button onClick={() => chooseSkin(item.id, item.price)}>{selected ? "AUSGERÜSTET" : owned ? "AUSRÜSTEN" : `🪙 ${item.price}`}</button></article>; })}
            {shopTab === "outfits" && OUTFITS.map((item) => { const owned = ownedOutfits.includes(item.id); const selected = selectedOutfit === item.id; return <article key={item.id} className={`shop-card ${selected ? "selected" : ""}`}><div className="shop-item-icon">{item.icon}</div><small>FAHRER-OUTFIT</small><h3>{item.name}</h3><p>In 3D- und Festnahmeszenen</p><button onClick={() => chooseOutfit(item.id, item.price)}>{selected ? "AUSGERÜSTET" : owned ? "AUSRÜSTEN" : `🪙 ${item.price}`}</button></article>; })}
            {shopTab === "powerups" && POWER_DEFS.map((item, index) => { const upgrade = powerUpgrades[item.id] ?? 0; const price = 140 + upgrade * 160 + Math.floor(index / 5) * 35; return <article key={item.id} className={`shop-card power-card ${upgrade >= 5 ? "selected" : ""}`}><div className="shop-item-icon" style={{ color: `#${item.color.toString(16).padStart(6, "0")}` }}>{item.icon}</div><small>LEVEL {index + 1} · STUFE {upgrade}/5</small><h3>{item.label}</h3><p>{item.description}</p><div className="upgrade-pips">{[1, 2, 3, 4, 5].map((pip) => <i key={pip} className={pip <= upgrade ? "on" : ""} />)}</div><button onClick={() => upgradePower(item.id, index)}>{upgrade >= 5 ? "MAXIMUM" : `VERBESSERN · 🪙 ${price}`}</button></article>; })}
          </div>
          <div className="shop-3d-label"><span>LIVE 3D-VORSCHAU</span><strong>{VEHICLES.find((item) => item.id === selectedVehicle)?.name}</strong><small>{SKINS.find((item) => item.id === selectedSkin)?.name} · {OUTFITS.find((item) => item.id === selectedOutfit)?.name}</small></div>
        </section>
      )}

      {status === "paused" && (
        <section className="modal pause-card">
          <div className="pause-icon">Ⅱ</div><p>RENNEN PAUSIERT</p><h2>{current.name}</h2><span>Die Jagd wartet. Setze das Rennen fort oder beginne die Mission neu.</span>
          <button className="primary-button" onClick={() => apiRef.current?.resume()}>WEITERFAHREN <span>▶</span></button>
          <div className="pause-actions"><button onClick={restartMission}>MISSION NEU STARTEN</button><button onClick={returnToMenu}>HAUPTMENÜ</button></div>
        </section>
      )}

      {status === "briefing" && (
        <section className="modal briefing-card">
          <div className="mission-number">MISSION {level + 1} / 30</div><div className="mission-icon">{current.icon}</div><p>{current.subtitle}</p><h2>{current.name}</h2><span className="mission-type">{current.mission}</span><p className="objective">{current.objective}</p>
          <div className="mission-features"><div><small>EXKLUSIVES POWER-UP</small><strong>{POWER_META[LEVEL_POWER[level]].icon} {POWER_META[LEVEL_POWER[level]].label}</strong></div><div><small>MUSIKTRACK · STARTET MIT DER MISSION</small><strong>♫ {MUSIC_TRACKS[level]}</strong></div></div>
          <div className="tip"><b>TIPP · STUFE {powerUpgrades[LEVEL_POWER[level]] ?? 0}/5</b>{POWER_META[LEVEL_POWER[level]].description} Im Shop kannst du Dauer und Stärke verbessern.</div>
          <button className="primary-button" onClick={engineFailed ? () => window.location.reload() : startMission} disabled={!engineReady && !engineFailed}>{engineFailed ? <>3D NEU STARTEN <span>↻</span></> : engineReady ? <>MISSION STARTEN <span>➜</span></> : <>3D WIRD VORBEREITET…</>}</button>
        </section>
      )}

      {status === "arresting" && (
        <section className="arrest-cinematic" aria-live="assertive">
          <div className="arrest-rec"><i /> POLIZEI-KAMERA · AUFNAHME</div>
          <p>FESTNAHMESEQUENZ</p><h2>{arrestCaption}</h2>
          <div className="arrest-timeline"><i /><i /><i /><i /><i /></div>
          <button onClick={skipArrest}>SZENE ÜBERSPRINGEN</button>
        </section>
      )}

      {status === "caught" && (
        <section className="modal caught-card"><div className="siren" aria-hidden="true"><i /><i /></div><p>FESTNAHME ABGESCHLOSSEN</p><h2>VERHAFTET!</h2><span>Der Polizist hat den Fluchtfahrer aus dem Wagen geholt und Handschellen angelegt. Nutze beim nächsten Versuch das exklusive Welt-Power-up.</span><button className="primary-button danger" onClick={restartMission}>MISSION NEU STARTEN</button><button className="text-button" onClick={returnToMenu}>Zurück zum Hauptmenü</button></section>
      )}

      {status === "complete" && (
        <section className="modal result-card"><div className="result-badge">✓</div><p>MISSION GESCHAFFT</p><h2>{current.name} bezwungen!</h2><div className="result-stats"><div><b>{Math.floor(hud.distance)}</b><span>Meter</span></div><div><b>{hud.coins}</b><span>Münzen</span></div><div><b>{Math.floor(hud.gap)}</b><span>Meter Vorsprung</span></div></div><button className="primary-button" onClick={() => apiRef.current?.next()}>NÄCHSTE WELT <span>➜</span></button></section>
      )}

      {status === "won" && (
        <section className="modal won-card"><div className="trophy">🏆</div><p>KAMPAGNE GESCHAFFT</p><h2>Rail-Rush-Legende!</h2><span>Du hast alle 30 langen 3D-Level, jeden Zug und das Catcher Car bezwungen.</span><div className="result-stats"><div><b>{hud.coins}</b><span>Münzen</span></div><div><b>30</b><span>Musiktracks</span></div><div><b>30</b><span>Power-ups</span></div></div><button className="primary-button" onClick={returnToMenu}>NOCH EINMAL SPIELEN</button></section>
      )}
    </main>
  );
}
