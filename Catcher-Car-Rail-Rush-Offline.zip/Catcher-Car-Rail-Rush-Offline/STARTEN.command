#!/bin/bash
cd "$(dirname "$0")"
open "SPIEL_STARTEN.html"
